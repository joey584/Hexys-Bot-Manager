"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Math Plugin — Hexy's Bot Manager
  /math  — evaluate expressions, unit conversions,
           constants, and step-by-step explanations
  No external API required — runs fully offline
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

# ─── Bootstrap dependencies ───────────────────────────────────────────────────
import sys
import subprocess
import importlib

for _mod, _pkg in {"discord": "discord.py"}.items():
    try:
        importlib.import_module(_mod)
    except ImportError:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", _pkg, "--quiet"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )

# ─── Imports ──────────────────────────────────────────────────────────────────
import os
import re
import ast
import math
import cmath
import json
import asyncio
import operator
import traceback
from pathlib import Path
from datetime import datetime, timezone

import discord
from discord import app_commands

# ─── Paths ────────────────────────────────────────────────────────────────────
PLUGIN_DIR = Path(__file__).parent
STATE_FILE = PLUGIN_DIR / "math_state.json"
PID_FILE   = PLUGIN_DIR / "math_plugin.pid"
LOG_FILE   = PLUGIN_DIR / "math_plugin.log"

# ─── Logger ───────────────────────────────────────────────────────────────────
def log(msg: str):
    line = f"[{datetime.now().strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

# ─── State helpers ────────────────────────────────────────────────────────────
def read_state() -> bool:
    try:
        return json.loads(STATE_FILE.read_text()).get("active", True)
    except Exception:
        return True

def write_state(active: bool):
    STATE_FILE.write_text(json.dumps({"active": active}))

def write_pid():
    PID_FILE.write_text(str(os.getpid()))

def clear_pid():
    try: PID_FILE.unlink()
    except Exception: pass

# ─── Safe expression evaluator ────────────────────────────────────────────────
# Uses AST walking instead of eval() so no arbitrary code can run.

SAFE_CONSTANTS = {
    "pi":    math.pi,
    "e":     math.e,
    "tau":   math.tau,
    "inf":   math.inf,
    "nan":   math.nan,
    "phi":   (1 + math.sqrt(5)) / 2,   # golden ratio
    "c":     299_792_458,               # speed of light (m/s)
    "g":     9.80665,                   # standard gravity (m/s²)
    "G":     6.674e-11,                 # gravitational constant
    "h":     6.626e-34,                 # Planck constant
    "kb":    1.380e-23,                 # Boltzmann constant
    "Na":    6.022e23,                  # Avogadro's number
}

SAFE_FUNCTIONS = {
    # Trig
    "sin":   math.sin,   "cos":   math.cos,   "tan":   math.tan,
    "asin":  math.asin,  "acos":  math.acos,  "atan":  math.atan,
    "atan2": math.atan2, "sinh":  math.sinh,  "cosh":  math.cosh,
    "tanh":  math.tanh,  "asinh": math.asinh, "acosh": math.acosh,
    "atanh": math.atanh,
    # Logarithms / exponentials
    "log":   math.log,   "log2":  math.log2,  "log10": math.log10,
    "exp":   math.exp,   "pow":   math.pow,
    # Rounding / misc
    "sqrt":  math.sqrt,  "cbrt":  lambda x: math.copysign(abs(x)**(1/3), x),
    "abs":   abs,        "ceil":  math.ceil,  "floor": math.floor,
    "round": round,      "fabs":  math.fabs,
    # Combinatorics
    "factorial": math.factorial,
    "gcd":   math.gcd,   "lcm":   math.lcm,
    "comb":  math.comb,  "perm":  math.perm,
    # Hypotenuse / degrees
    "hypot": math.hypot,
    "degrees": math.degrees, "radians": math.radians,
    # Sum / min / max on sequences
    "sum":   sum,        "min":   min,        "max":   max,
}

class _UnsafeNode(Exception):
    pass

class SafeEval(ast.NodeVisitor):
    """Walks a Python AST and evaluates only whitelisted nodes."""

    BINOPS = {
        ast.Add:      operator.add,
        ast.Sub:      operator.sub,
        ast.Mult:     operator.mul,
        ast.Div:      operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod:      operator.mod,
        ast.Pow:      operator.pow,
        ast.BitXor:   operator.xor,
        ast.BitAnd:   operator.and_,
        ast.BitOr:    operator.or_,
        ast.LShift:   operator.lshift,
        ast.RShift:   operator.rshift,
    }
    UNOPS = {
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }

    def visit_Expression(self, node):
        return self.visit(node.body)

    def visit_Constant(self, node):
        if isinstance(node.value, (int, float, complex)):
            return node.value
        raise _UnsafeNode(f"Unsupported constant type: {type(node.value)}")

    def visit_Name(self, node):
        name = node.id
        if name in SAFE_CONSTANTS:
            return SAFE_CONSTANTS[name]
        if name in SAFE_FUNCTIONS:
            return SAFE_FUNCTIONS[name]
        raise _UnsafeNode(f"Unknown name: '{name}'")

    def visit_BinOp(self, node):
        op_type = type(node.op)
        if op_type not in self.BINOPS:
            raise _UnsafeNode(f"Unsupported operator: {op_type.__name__}")
        left  = self.visit(node.left)
        right = self.visit(node.right)
        result = self.BINOPS[op_type](left, right)
        # Guard against ridiculous intermediate values
        if isinstance(result, float) and math.isfinite(result) and abs(result) > 1e300:
            raise OverflowError("Result too large to display")
        return result

    def visit_UnaryOp(self, node):
        op_type = type(node.op)
        if op_type not in self.UNOPS:
            raise _UnsafeNode(f"Unsupported unary operator: {op_type.__name__}")
        return self.UNOPS[op_type](self.visit(node.operand))

    def visit_Call(self, node):
        if not isinstance(node.func, ast.Name):
            raise _UnsafeNode("Only simple function calls are allowed")
        fname = node.func.id
        if fname not in SAFE_FUNCTIONS:
            raise _UnsafeNode(f"Unknown function: '{fname}'")
        fn   = SAFE_FUNCTIONS[fname]
        args = [self.visit(a) for a in node.args]
        if node.keywords:
            raise _UnsafeNode("Keyword arguments are not supported")
        return fn(*args)

    def visit_IfExp(self, node):
        # Allow ternary: value_if_true if condition else value_if_false
        test = self.visit(node.test)
        return self.visit(node.body) if test else self.visit(node.orelse)

    def visit_Compare(self, node):
        left = self.visit(node.left)
        for op, comp in zip(node.ops, node.comparators):
            right = self.visit(comp)
            ops_map = {
                ast.Eq: operator.eq, ast.NotEq: operator.ne,
                ast.Lt: operator.lt, ast.LtE:   operator.le,
                ast.Gt: operator.gt, ast.GtE:   operator.ge,
            }
            if type(op) not in ops_map:
                raise _UnsafeNode(f"Unsupported comparison: {type(op).__name__}")
            if not ops_map[type(op)](left, right):
                return False
            left = right
        return True

    def visit_Tuple(self, node):
        return tuple(self.visit(e) for e in node.elts)

    def visit_List(self, node):
        return list(self.visit(e) for e in node.elts)

    def generic_visit(self, node):
        raise _UnsafeNode(f"Disallowed AST node: {type(node).__name__}")


def safe_eval(expr: str):
    """
    Evaluate a math expression safely.
    Returns (result, error_message).
    """
    # Pre-process convenience replacements
    expr = expr.strip()
    expr = re.sub(r'\^', '**', expr)          # ^ → **  (XOR would still work via ^)
    expr = re.sub(r'×', '*', expr)            # × → *
    expr = re.sub(r'÷', '/', expr)            # ÷ → /
    expr = re.sub(r'√(\w+)', r'sqrt(\1)', expr)  # √x → sqrt(x)

    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as e:
        return None, f"Syntax error: {e}"

    evaluator = SafeEval()
    try:
        result = evaluator.visit(tree)
        return result, None
    except _UnsafeNode as e:
        return None, f"Not allowed: {e}"
    except ZeroDivisionError:
        return None, "Division by zero 🤕"
    except OverflowError as e:
        return None, str(e)
    except ValueError as e:
        return None, f"Math error: {e}"
    except Exception as e:
        return None, f"Error: {e}"


def format_result(result) -> str:
    """Format a result value into a clean human-readable string."""
    if isinstance(result, complex):
        r, i = result.real, result.imag
        if i == 0:
            return format_result(r)
        sign = "+" if i >= 0 else "-"
        return f"{format_result(r)} {sign} {format_result(abs(i))}i"

    if isinstance(result, bool):
        return "True" if result else "False"

    if isinstance(result, int):
        if abs(result) > 1_000_000_000:
            return f"{result:,}  ≈  {result:.6e}"
        return f"{result:,}"

    if isinstance(result, float):
        if math.isnan(result):  return "NaN"
        if math.isinf(result):  return "∞" if result > 0 else "-∞"
        if result == int(result) and abs(result) < 1e15:
            return f"{int(result):,}"
        if abs(result) > 1e10 or (abs(result) < 1e-4 and result != 0):
            return f"{result:.6e}"
        # Trim trailing zeros
        s = f"{result:.10f}".rstrip("0").rstrip(".")
        # Add thousands separator to integer part
        parts = s.split(".")
        parts[0] = f"{int(parts[0]):,}"
        return ".".join(parts)

    if isinstance(result, (tuple, list)):
        bracket = ("(", ")") if isinstance(result, tuple) else ("[", "]")
        return bracket[0] + ", ".join(format_result(v) for v in result) + bracket[1]

    return str(result)


# ─── Unit conversion engine ───────────────────────────────────────────────────
# Each entry: (canonical_unit, factor_to_SI, SI_unit, aliases...)
UNIT_TABLE = [
    # Length
    ("metre",       1,              "m",   "m", "meter", "metres", "meters"),
    ("kilometre",   1_000,          "m",   "km", "kilometer", "kilometres", "kilometers"),
    ("centimetre",  0.01,           "m",   "cm", "centimeter", "centimetres"),
    ("millimetre",  0.001,          "m",   "mm", "millimeter", "millimetres"),
    ("inch",        0.0254,         "m",   "in", "inch", "inches", "\""),
    ("foot",        0.3048,         "m",   "ft", "foot", "feet", "'"),
    ("yard",        0.9144,         "m",   "yd", "yard", "yards"),
    ("mile",        1609.344,       "m",   "mi", "mile", "miles"),
    ("nautical mile", 1852,         "m",   "nmi", "nautical mile", "nautical miles"),
    ("light-year",  9.461e15,       "m",   "ly", "light year", "light-year", "light years"),
    # Mass
    ("kilogram",    1,              "kg",  "kg", "kilogram", "kilograms"),
    ("gram",        0.001,          "kg",  "g", "gram", "grams"),
    ("milligram",   1e-6,           "kg",  "mg", "milligram", "milligrams"),
    ("tonne",       1000,           "kg",  "t", "tonne", "tonnes", "metric ton"),
    ("pound",       0.45359237,     "kg",  "lb", "lbs", "pound", "pounds"),
    ("ounce",       0.028349523,    "kg",  "oz", "ounce", "ounces"),
    ("stone",       6.35029318,     "kg",  "st", "stone", "stones"),
    # Temperature (handled separately)
    # Volume
    ("litre",       0.001,          "m³",  "l", "L", "litre", "liter", "litres", "liters"),
    ("millilitre",  1e-6,           "m³",  "ml", "mL", "millilitre", "milliliter"),
    ("cubic metre", 1,              "m³",  "m3", "m³", "cubic metre", "cubic meter"),
    ("gallon",      0.00378541,     "m³",  "gal", "gallon", "gallons", "US gallon"),
    ("UK gallon",   0.00454609,     "m³",  "UK gal", "imperial gallon", "imp gal"),
    ("quart",       0.000946353,    "m³",  "qt", "quart", "quarts"),
    ("pint",        0.000473176,    "m³",  "pt", "pint", "pints"),
    ("cup",         0.000236588,    "m³",  "cup", "cups"),
    ("fluid ounce", 2.95735e-5,     "m³",  "fl oz", "fluid ounce", "fluid ounces", "floz"),
    # Time
    ("second",      1,              "s",   "s", "sec", "second", "seconds"),
    ("minute",      60,             "s",   "min", "minute", "minutes"),
    ("hour",        3600,           "s",   "h", "hr", "hour", "hours"),
    ("day",         86400,          "s",   "d", "day", "days"),
    ("week",        604800,         "s",   "wk", "week", "weeks"),
    ("year",        31_557_600,     "s",   "yr", "year", "years"),
    # Speed
    ("m/s",         1,              "m/s", "m/s", "mps", "metres per second"),
    ("km/h",        1/3.6,          "m/s", "kmh", "km/h", "kph", "kilometres per hour"),
    ("mph",         0.44704,        "m/s", "mph", "miles per hour"),
    ("knot",        0.514444,       "m/s", "kt", "kn", "knot", "knots"),
    # Energy
    ("joule",       1,              "J",   "j", "J", "joule", "joules"),
    ("kilojoule",   1000,           "J",   "kj", "kJ", "kilojoule", "kilojoules"),
    ("calorie",     4.184,          "J",   "cal", "calorie", "calories"),
    ("kilocalorie", 4184,           "J",   "kcal", "kilocalorie", "kilocalories", "Cal"),
    ("watt-hour",   3600,           "J",   "wh", "Wh", "watt hour", "watt-hour"),
    ("kWh",         3_600_000,      "J",   "kwh", "kWh", "kilowatt hour"),
    ("electronvolt",1.602e-19,      "J",   "ev", "eV", "electronvolt"),
    ("BTU",         1055.06,        "J",   "btu", "BTU"),
    # Power
    ("watt",        1,              "W",   "w", "W", "watt", "watts"),
    ("kilowatt",    1000,           "W",   "kw", "kW", "kilowatt", "kilowatts"),
    ("megawatt",    1e6,            "W",   "MW", "megawatt"),
    ("horsepower",  745.7,          "W",   "hp", "horsepower"),
    # Pressure
    ("pascal",      1,              "Pa",  "pa", "Pa", "pascal", "pascals"),
    ("kilopascal",  1000,           "Pa",  "kpa", "kPa", "kilopascal"),
    ("bar",         100_000,        "Pa",  "bar"),
    ("atmosphere",  101_325,        "Pa",  "atm", "atmosphere", "atmospheres"),
    ("psi",         6894.76,        "Pa",  "psi", "PSI"),
    ("mmHg",        133.322,        "Pa",  "mmhg", "mmHg", "torr"),
    # Data
    ("bit",         1,              "bit", "bit", "bits"),
    ("byte",        8,              "bit", "B", "byte", "bytes"),
    ("kilobyte",    8_000,          "bit", "kB", "KB", "kilobyte", "kilobytes"),
    ("megabyte",    8_000_000,      "bit", "MB", "megabyte", "megabytes"),
    ("gigabyte",    8e9,            "bit", "GB", "gigabyte", "gigabytes"),
    ("terabyte",    8e12,           "bit", "TB", "terabyte", "terabytes"),
    ("kibibyte",    8_192,          "bit", "KiB", "kibibyte"),
    ("mebibyte",    8_388_608,      "bit", "MiB", "mebibyte"),
    ("gibibyte",    8_589_934_592,  "bit", "GiB", "gibibyte"),
    # Angle
    ("radian",      1,              "rad", "rad", "radian", "radians"),
    ("degree",      math.pi/180,    "rad", "deg", "°", "degree", "degrees"),
    ("gradian",     math.pi/200,    "rad", "grad", "gradian", "gradians"),
    # Area
    ("sq metre",    1,              "m²",  "m2", "m²", "sq m", "sqm"),
    ("sq kilometre",1e6,            "m²",  "km2", "km²", "sq km"),
    ("sq mile",     2.59e6,         "m²",  "sq mi", "sq mile"),
    ("acre",        4046.86,        "m²",  "acre", "acres"),
    ("hectare",     10_000,         "m²",  "ha", "hectare", "hectares"),
    ("sq foot",     0.092903,       "m²",  "sq ft", "sq foot", "sqft"),
    ("sq inch",     0.00064516,     "m²",  "sq in", "sq inch"),
]

# Build lookup: alias → (canonical, factor, SI_unit)
_UNIT_LOOKUP: dict[str, tuple[str, float, str]] = {}
for _entry in UNIT_TABLE:
    _canon, _factor, _si = _entry[0], _entry[1], _entry[2]
    for _alias in _entry[3:]:
        _UNIT_LOOKUP[_alias.lower()] = (_canon, _factor, _si)


def convert_units(value: float, from_unit: str, to_unit: str) -> tuple[float | None, str]:
    """
    Convert value from from_unit to to_unit.
    Returns (result, error_string).  error_string is "" on success.
    """
    fu = from_unit.strip().lower()
    tu = to_unit.strip().lower()

    # ── Temperature (special: not a simple multiply) ──────────────────────────
    temp_map = {
        "c": "celsius", "°c": "celsius", "celsius": "celsius",
        "f": "fahrenheit", "°f": "fahrenheit", "fahrenheit": "fahrenheit",
        "k": "kelvin", "kelvin": "kelvin",
        "r": "rankine", "°r": "rankine", "rankine": "rankine",
    }
    if fu in temp_map and tu in temp_map:
        src, dst = temp_map[fu], temp_map[tu]

        def to_kelvin(v, unit):
            if unit == "celsius":    return v + 273.15
            if unit == "fahrenheit": return (v + 459.67) * 5/9
            if unit == "rankine":    return v * 5/9
            return v  # kelvin

        def from_kelvin(v, unit):
            if unit == "celsius":    return v - 273.15
            if unit == "fahrenheit": return v * 9/5 - 459.67
            if unit == "rankine":    return v * 9/5
            return v  # kelvin

        k = to_kelvin(value, src)
        if k < 0:
            return None, "Absolute temperature cannot be below 0 K"
        return from_kelvin(k, dst), ""

    # ── Normal unit conversion ────────────────────────────────────────────────
    if fu not in _UNIT_LOOKUP:
        return None, f"Unknown unit: '{from_unit}'"
    if tu not in _UNIT_LOOKUP:
        return None, f"Unknown unit: '{to_unit}'"

    from_canon, from_factor, from_si = _UNIT_LOOKUP[fu]
    to_canon,   to_factor,   to_si   = _UNIT_LOOKUP[tu]

    if from_si != to_si:
        return None, (
            f"Incompatible unit types: **{from_canon}** ({from_si}) "
            f"↔ **{to_canon}** ({to_si})"
        )

    result = value * from_factor / to_factor
    return result, ""


# ─── Conversion auto-detect parser ───────────────────────────────────────────
# Matches patterns like:  "5 km to miles"  /  "100°F in C"  /  "1 kg → lbs"
CONV_PATTERN = re.compile(
    r'^([\-\+]?\d+(?:[.,]\d+)?(?:e[\-\+]?\d+)?)'    # number
    r'\s*'
    r'([^\d\s→\-][^→\-]*?)'                           # from-unit (greedy til arrow/keyword)
    r'\s*(?:to|in|into|→|->)\s*'                       # separator
    r'([^\d\s].*)$',                                   # to-unit
    re.IGNORECASE,
)


def try_parse_conversion(text: str) -> tuple[float, str, str] | None:
    """Return (value, from_unit, to_unit) or None."""
    m = CONV_PATTERN.match(text.strip())
    if not m:
        return None
    raw_num = m.group(1).replace(",", "")
    try:
        value = float(raw_num)
    except ValueError:
        return None
    to_unit = m.group(3).strip()
    # "into cm" can leave a stray "to " prefix — clean it up
    to_unit = re.sub(r'^to\s+', '', to_unit, flags=re.IGNORECASE).strip()
    return value, m.group(2).strip(), to_unit


# ─── Discord bot ──────────────────────────────────────────────────────────────
intents = discord.Intents.default()
client  = discord.Client(intents=intents)
tree    = app_commands.CommandTree(client)

_active = True

async def state_poller():
    global _active
    while True:
        try:
            _active = read_state()
        except Exception:
            pass
        await asyncio.sleep(3)


# ─── /math command ────────────────────────────────────────────────────────────
@tree.command(
    name="math",
    description="Evaluate math expressions, convert units, or look up constants.",
)
@app_commands.describe(
    expression=(
        "Expression, e.g.  sin(pi/4)  •  100 km to miles  •  "
        "log(1000, 10)  •  phi^2  •  5! "
    )
)
async def math_command(interaction: discord.Interaction, expression: str):
    log(f"/math called by {interaction.user}: '{expression}'")

    if not _active:
        embed = discord.Embed(
            title="❌  Math Feature Disabled",
            description=(
                "The **Math** feature has been turned off by the administrator.\n"
                "Ask them to re-enable it in **Hexy's Bot Manager**."
            ),
            colour=discord.Colour.from_rgb(180, 40, 60),
        )
        embed.set_footer(text="Hexy's Bot Manager")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    expr = expression.strip()
    expr_display = expr

    # ── 1. Unit conversion shortcut ───────────────────────────────────────────
    conv = try_parse_conversion(expr)
    if conv is not None:
        value, from_unit, to_unit = conv
        result, err = convert_units(value, from_unit, to_unit)
        if err:
            embed = discord.Embed(
                title="⚠️  Conversion Error",
                description=err,
                colour=discord.Colour.orange(),
            )
            embed.set_footer(text="Hexy's Bot Manager  •  /math")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        result_str = format_result(result)
        # Find canonical unit names for display
        fu_key = from_unit.strip().lower()
        tu_key = to_unit.strip().lower()
        from_canon = _UNIT_LOOKUP[fu_key][0] if fu_key in _UNIT_LOOKUP else from_unit
        to_canon   = _UNIT_LOOKUP[tu_key][0] if tu_key in _UNIT_LOOKUP else to_unit
        # Temperature doesn't use _UNIT_LOOKUP
        temp_map_display = {
            "c": "Celsius", "°c": "Celsius", "celsius": "Celsius",
            "f": "Fahrenheit", "°f": "Fahrenheit", "fahrenheit": "Fahrenheit",
            "k": "Kelvin", "kelvin": "Kelvin",
            "r": "Rankine", "°r": "Rankine", "rankine": "Rankine",
        }
        if fu_key in temp_map_display:
            from_canon = temp_map_display[fu_key]
        if tu_key in temp_map_display:
            to_canon   = temp_map_display[tu_key]

        embed = discord.Embed(
            title="📐  Unit Conversion",
            colour=discord.Colour.from_rgb(80, 160, 220),
        )
        embed.add_field(
            name="Input",
            value=f"`{format_result(value)} {from_unit}`",
            inline=True,
        )
        embed.add_field(name="↓", value="converts to", inline=True)
        embed.add_field(
            name="Output",
            value=f"**`{result_str} {to_unit}`**",
            inline=True,
        )
        embed.add_field(
            name="Units",
            value=f"{from_canon}  →  {to_canon}",
            inline=False,
        )
        embed.set_footer(
            text=f"Hexy's Bot Manager  •  /math  •  {interaction.user.display_name}"
        )
        await interaction.response.send_message(embed=embed)
        return

    # ── 2. Constant lookup ("what is pi", "pi", "golden ratio", etc.) ─────────
    CONSTANT_ALIASES = {
        "pi": "pi", "π": "pi",
        "e": "e", "euler": "e",
        "tau": "tau", "τ": "tau",
        "phi": "phi", "φ": "phi", "golden ratio": "phi", "golden": "phi",
        "c": "c", "speed of light": "c",
        "g": "g", "gravity": "g", "standard gravity": "g",
        "big g": "G", "gravitational constant": "G",
        "planck": "h", "planck constant": "h",
        "boltzmann": "kb", "boltzmann constant": "kb",
        "avogadro": "Na", "avogadro number": "Na",
    }
    expr_lower = expr.lower().strip("? \t")
    for alias, key in CONSTANT_ALIASES.items():
        if expr_lower == alias:
            val = SAFE_CONSTANTS[key]
            embed = discord.Embed(
                title=f"📖  Constant: {key}",
                colour=discord.Colour.from_rgb(140, 100, 220),
            )
            embed.add_field(name="Value", value=f"**`{val}`**", inline=False)
            CONST_DESCS = {
                "pi":  "Ratio of a circle's circumference to its diameter",
                "e":   "Euler's number — base of the natural logarithm",
                "tau": "2π — full turn in radians",
                "phi": "The golden ratio  (1 + √5) / 2",
                "c":   "Speed of light in a vacuum (m/s)",
                "g":   "Standard gravitational acceleration on Earth (m/s²)",
                "G":   "Newton's gravitational constant (N·m²/kg²)",
                "h":   "Planck constant (J·s)",
                "kb":  "Boltzmann constant (J/K)",
                "Na":  "Avogadro's number (mol⁻¹)",
            }
            if key in CONST_DESCS:
                embed.add_field(name="Description", value=CONST_DESCS[key], inline=False)
            embed.set_footer(text="Hexy's Bot Manager  •  /math")
            await interaction.response.send_message(embed=embed)
            return

    # ── 3. General expression evaluation ─────────────────────────────────────
    result, err = safe_eval(expr)

    if err:
        embed = discord.Embed(
            title="❌  Math Error",
            colour=discord.Colour.from_rgb(200, 50, 70),
        )
        embed.add_field(name="Expression", value=f"`{expr_display}`", inline=False)
        embed.add_field(name="Problem",    value=err,                  inline=False)
        embed.add_field(
            name="Tips",
            value=(
                "• Use `**` for powers, or `^`  (e.g. `2**10` or `2^10`)\n"
                "• Functions: `sin`, `cos`, `log`, `sqrt`, `factorial`, …\n"
                "• Constants: `pi`, `e`, `phi`, `tau`\n"
                "• Conversions: `100 km to miles`  •  `32 F to C`"
            ),
            inline=False,
        )
        embed.set_footer(text="Hexy's Bot Manager  •  /math")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        return

    result_str = format_result(result)

    # Pick embed colour based on result magnitude (purely cosmetic fun)
    if isinstance(result, (int, float)) and math.isfinite(float(result)):
        v = abs(float(result))
        if v == 0:
            colour = discord.Colour.from_rgb(100, 100, 100)
        elif v < 1:
            colour = discord.Colour.from_rgb(80, 200, 160)
        elif v < 1000:
            colour = discord.Colour.from_rgb(100, 200, 80)
        elif v < 1e9:
            colour = discord.Colour.from_rgb(220, 180, 40)
        else:
            colour = discord.Colour.from_rgb(220, 80, 40)
    else:
        colour = discord.Colour.from_rgb(140, 100, 220)

    embed = discord.Embed(title="🧮  Math Result", colour=colour)
    embed.add_field(name="Expression", value=f"`{expr_display}`",  inline=False)
    embed.add_field(name="Result",     value=f"**`{result_str}`**", inline=False)

    # Add a bonus fun fact for some recognisable results
    facts = {
        "3.141592653589793": "That's π!",
        "2.718281828459045": "That's e (Euler's number)!",
        "1.618033988749895": "That's φ, the golden ratio!",
        "6.283185307179586": "That's τ (tau) = 2π!",
        "42": "The Answer to the Ultimate Question of Life, the Universe, and Everything.",
        "0": "Zero — the additive identity.",
        "1": "One — the multiplicative identity.",
        "1024": "2¹⁰ — a classic power of two!",
        "299792458": "That's the speed of light in m/s!",
    }
    if result_str.replace(",", "") in facts:
        embed.add_field(name="✨  Fun Fact", value=facts[result_str.replace(",", "")], inline=False)

    embed.set_footer(
        text=f"Hexy's Bot Manager  •  /math  •  {interaction.user.display_name}"
    )
    await interaction.response.send_message(embed=embed)


# ─── Autocomplete — expression suggestions ────────────────────────────────────
EXAMPLE_EXPRS = [
    "sin(pi / 4)",
    "cos(pi) + 1",
    "sqrt(144)",
    "log(1000, 10)",
    "2 ** 32",
    "factorial(10)",
    "gcd(48, 18)",
    "hypot(3, 4)",
    "100 km to miles",
    "32 F to C",
    "1 kg to lbs",
    "1 hour to seconds",
    "1 kWh to joules",
    "1 atm to psi",
    "pi",
    "phi",
    "e",
]

@math_command.autocomplete("expression")
async def math_autocomplete(
    interaction: discord.Interaction,
    current: str,
) -> list[app_commands.Choice[str]]:
    try:
        if not current:
            return [
                app_commands.Choice(name=ex, value=ex)
                for ex in EXAMPLE_EXPRS[:10]
            ]
        low = current.lower()
        matches = [
            app_commands.Choice(name=ex, value=ex)
            for ex in EXAMPLE_EXPRS
            if low in ex.lower()
        ]
        # Also offer the raw expression so they can just submit it
        if current not in [m.value for m in matches]:
            matches.insert(0, app_commands.Choice(name=current, value=current))
        return matches[:25]
    except Exception:
        log(f"Autocomplete error:\n{traceback.format_exc()}")
        return []


# ─── Tree error handler ───────────────────────────────────────────────────────
@tree.error
async def on_app_command_error(
    interaction: discord.Interaction,
    error: app_commands.AppCommandError,
):
    log(f"App command error: {error}\n{traceback.format_exc()}")
    try:
        await interaction.response.send_message(
            f"❌  An error occurred: {error}", ephemeral=True
        )
    except Exception:
        pass


# ─── Client events ────────────────────────────────────────────────────────────
@client.event
async def on_ready():
    global _active
    _active = read_state()
    log(f"Logged in as {client.user}  ({client.user.id})")
    log(f"In {len(client.guilds)} guild(s)")

    for guild in client.guilds:
        try:
            tree.copy_global_to(guild=guild)
            await tree.sync(guild=guild)
            log(f"Synced to guild: {guild.name}")
        except Exception:
            log(f"Guild sync failed for {guild.name}:\n{traceback.format_exc()}")

    try:
        synced = await tree.sync()
        log(f"Global sync: {len(synced)} command(s)")
    except Exception:
        log(f"Global sync error:\n{traceback.format_exc()}")

    asyncio.create_task(state_poller())
    log("State poller started.  Ready!")
    log(f"Feature active: {_active}")


# ─── Entry point ──────────────────────────────────────────────────────────────
def parse_args() -> tuple[str, str]:
    args  = sys.argv[1:]
    token = ""
    state = "on"
    for i, a in enumerate(args):
        if a == "--token" and i + 1 < len(args): token = args[i + 1]
        if a == "--state" and i + 1 < len(args): state = args[i + 1]
    return token, state


def main():
    token, state = parse_args()

    if not token:
        log("ERROR: No token. Launch via Hexy's Bot Manager.")
        sys.exit(1)

    write_state(state == "on")

    if state == "off":
        log("State → OFF. Running instance will notice within 3 seconds.")
        return

    if PID_FILE.exists():
        log(f"Already running (PID {PID_FILE.read_text().strip()}). State → ON.")
        return

    write_pid()
    import atexit
    atexit.register(clear_pid)

    log("=" * 50)
    log("Math Plugin starting…")
    log(f"Log file: {LOG_FILE}")
    log("=" * 50)

    try:
        client.run(token, log_handler=None)
    except discord.LoginFailure:
        log("ERROR: Invalid token.")
    except Exception:
        log(f"Fatal error:\n{traceback.format_exc()}")
    finally:
        clear_pid()


if __name__ == "__main__":
    main()
