"""
╔══════════════════════════════════════════════════╗
║             Hexy's Bot Manager                   ║
║         Open-Source Bot Management Suite         ║
╚══════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  PLUGIN / FEATURE SYSTEM — HOW TO ADD YOUR OWN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Find the FEATURES list below (search "FEATURES =").
  Each entry is a dict with these keys:

    "name"        – Display name shown in the UI
    "description" – Short description shown under the button
    "script"      – Python file to run (relative to this script's folder)
                    Set to None for built-in features.
    "builtin"     – True = handled internally, False = launches your script

  When your feature script is toggled ON or OFF, it is launched like this:

    python your_script.py --token BOT_TOKEN --state on|off

  Your script receives:
    sys.argv[1]  →  "--token"
    sys.argv[2]  →  the bot token string
    sys.argv[3]  →  "--state"
    sys.argv[4]  →  "on" or "off"

  The script's terminal window is automatically minimized on Windows
  so it stays out of the way.

  Example feature entry:
    {
        "name":        "Auto Responder",
        "description": "Replies to keywords automatically.",
        "script":      "auto_responder.py",
        "builtin":     False,
    },
"""

# ══════════════════════════════════════════════════════════════════════════════
# ▶  FEATURES LIST — Edit this to add your own features
# ══════════════════════════════════════════════════════════════════════════════
FEATURES = [
    {
        "name":        "Lockdown Bot",
        "description": "Prevents the bot from sending messages or\n"
                       "responding to any slash commands.",
        "script":      None,     # Built-in — handled by this file
        "builtin":     True,
        "builtin_key": "lockdown",
    },
    # ── Add your own features below this line ─────────────────────────────────
    {
        "name":        "Math Command",
        "description": "Adds /math — evaluate expressions, convert units,\n"
                       "and look up constants. No API key needed.",
        "script":      "math_plugin.py",
        "builtin":     False,
    },
    {
        "name":        "Weather Command",
        "description": "Adds /weather — lets users pick any city worldwide\n"
                       "and get live weather data. Free API, no key needed.",
        "script":      "weather_plugin.py",
        "builtin":     False,
    },
    # {
    #     "name":        "Auto Responder",
    #     "description": "Replies to trigger keywords automatically.",
    #     "script":      "auto_responder.py",
    #     "builtin":     False,
    # },
]
# ══════════════════════════════════════════════════════════════════════════════


# ─── Dependency bootstrapper (runs before anything else) ──────────────────────
import sys
import subprocess
import importlib

REQUIRED = {
    "discord":    "discord.py",
    "requests":   "requests",
    "PIL":        "Pillow",
    "aiohttp":    "aiohttp",
}

def check_and_install_deps():
    missing = []
    for module, package in REQUIRED.items():
        try:
            importlib.import_module(module)
        except ImportError:
            missing.append(package)

    if not missing:
        return

    import tkinter as tk
    from tkinter import ttk

    root = tk.Tk()
    root.title("Hexy's Bot Manager – First-Time Setup")
    root.geometry("480x210")
    root.configure(bg="#1a1a2e")
    root.resizable(False, False)

    tk.Label(root, text="Installing missing dependencies…",
             bg="#1a1a2e", fg="#e0e0ff",
             font=("Segoe UI", 12, "bold")).pack(pady=(28, 8))
    bar = ttk.Progressbar(root, length=400, mode="determinate",
                          maximum=len(missing))
    bar.pack(pady=6)
    status = tk.Label(root, text="", bg="#1a1a2e", fg="#9090c0",
                      font=("Segoe UI", 9))
    status.pack(pady=2)
    root.update()

    for i, pkg in enumerate(missing):
        status.config(text=f"pip install {pkg} …")
        bar["value"] = i
        root.update()
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
        bar["value"] = i + 1
        root.update()

    status.config(text="✓ All done!  Launching Hexy's Bot Manager…")
    root.update()
    root.after(1600, root.destroy)
    root.mainloop()


check_and_install_deps()

# ─── Full imports ─────────────────────────────────────────────────────────────
import os
import json
import time
import asyncio
import threading
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from io import BytesIO
from datetime import datetime, timedelta, timezone

import requests
from PIL import Image, ImageTk, ImageDraw
import discord
from discord.ext import commands

# ─── Config ───────────────────────────────────────────────────────────────────
APP_NAME    = "Hexy's Bot Manager"
PROJECT_DIR   = Path(__file__).parent
ICON_NAME     = "Moon"
CONFIG_FILE   = PROJECT_DIR / "hexy_config.json"
SCHEDULE_FILE = PROJECT_DIR / "mod_schedule.json"   # pending temp-ban expiries
LOG_MAX       = 300

# ─── Temp-ban persistence ─────────────────────────────────────────────────────
# Stores full absolute UTC date+time (not just a clock time) for every
# pending auto-unban, so a restart never confuses "10 PM yesterday" with
# "10 PM today" — the stored value already carries its own date.
def _load_schedule() -> list:
    try:
        return json.loads(SCHEDULE_FILE.read_text())
    except Exception:
        return []

def _save_schedule(entries: list):
    try:
        SCHEDULE_FILE.write_text(json.dumps(entries, indent=2))
    except Exception:
        pass

def _add_schedule_entry(guild_id: int, user_id: int, unban_at, banned_at):
    entries = _load_schedule()
    entries.append({
        "guild_id":  guild_id,
        "user_id":   user_id,
        "unban_at":  unban_at.isoformat(),   # full ISO date+time, timezone-aware
        "banned_at": banned_at.isoformat(),
    })
    _save_schedule(entries)

def _remove_schedule_entry(guild_id: int, user_id: int):
    entries = _load_schedule()
    entries = [e for e in entries
              if not (e["guild_id"] == guild_id and e["user_id"] == user_id)]
    _save_schedule(entries)


BG_DARK   = "#0d0d1a";  BG_PANEL  = "#111128";  BG_CARD   = "#18183a"
ACCENT    = "#7b5ea7";  ACCENT_LT = "#a07dd0";  TXT_PRI   = "#e8e8ff"
TXT_SEC   = "#8888aa";  TXT_MUT   = "#454565";  BORDER    = "#252548"
LOG_BG    = "#09091e";  SUCCESS   = "#4caf8a";  WARNING   = "#f0a050"
ERR       = "#e05070";  LOCK_RED  = "#c0304a";  LOCK_BG   = "#200010"

# ─── Project structure ────────────────────────────────────────────────────────
def ensure_project_structure():
    for folder in ("logs", "plugins", "assets"):
        (PROJECT_DIR / folder).mkdir(exist_ok=True)
    if not CONFIG_FILE.exists():
        CONFIG_FILE.write_text(json.dumps({"token": "", "last_launch": ""}, indent=2))

ensure_project_structure()

# ─── Icon helpers ─────────────────────────────────────────────────────────────
def find_icon():
    for ext in (".ico", ".png", ".jpg", ".jpeg", ".webp", ".bmp"):
        p = PROJECT_DIR / (ICON_NAME + ext)
        if p.exists():
            return p
    return None

def to_ico(src):
    try:
        out = PROJECT_DIR / "Moon.ico"
        img = Image.open(src).convert("RGBA").resize((256, 256), Image.LANCZOS)
        img.save(out, format="ICO",
                 sizes=[(256,256),(128,128),(64,64),(32,32),(16,16)])
        return out
    except Exception:
        return None

def set_taskbar_icon(root, ico):
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            "Hexy.BotManager.1")
        root.iconbitmap(str(ico))
        root.wm_iconbitmap(str(ico))
    except Exception:
        pass

def circle_photo(src, size):
    try:
        img  = Image.open(src).convert("RGBA").resize(size, Image.LANCZOS)
        mask = Image.new("L", size, 0)
        ImageDraw.Draw(mask).ellipse((0, 0, size[0]-1, size[1]-1), fill=255)
        img.putalpha(mask)
        return ImageTk.PhotoImage(img)
    except Exception:
        return None

# ─── Chat feature: serialization helpers ─────────────────────────────────────
def _serialize_message(msg) -> dict:
    return {
        "id":            msg.id,
        "author_id":     msg.author.id,
        "author_name":   str(msg.author),
        "author_avatar": str(msg.author.display_avatar.url),
        "content":       msg.content or "(no text content)",
        "created_at":    msg.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        "guild_id":      msg.guild.id if msg.guild else None,
    }

def _serialize_member(m) -> dict:
    return {
        "id":           m.id,
        "name":         str(m),
        "display_name": m.display_name,
        "avatar_url":   str(m.display_avatar.url),
        "joined_at":    m.joined_at.strftime("%Y-%m-%d %H:%M:%S") if m.joined_at else "—",
        "top_role":     m.top_role.name if m.top_role else "—",
        "is_bot":       m.bot,
        "guild_id":     m.guild.id,
    }

# ─── Shared scrollable-frame helper ──────────────────────────────────────────
def _make_scrollable(parent, bg):
    """
    Packs a scrollable Canvas+Scrollbar into `parent` and returns the inner
    Frame that content should be added to. Used by every browser/list dialog
    (channel browser, voice member list, etc.) so the scroll wiring only
    lives in one place.
    """
    canvas = tk.Canvas(parent, bg=bg, bd=0, highlightthickness=0)
    sb     = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    inner  = tk.Frame(canvas, bg=bg)
    win_id = canvas.create_window((0, 0), window=inner, anchor="nw")

    def _on_resize(e):
        canvas.itemconfig(win_id, width=e.width)
    canvas.bind("<Configure>", _on_resize)

    def _on_frame_configure(_):
        canvas.configure(scrollregion=canvas.bbox("all"))
    inner.bind("<Configure>", _on_frame_configure)

    def _on_wheel(e):
        canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
    canvas.bind("<MouseWheel>", _on_wheel)
    inner.bind("<MouseWheel>", _on_wheel)

    return inner

# ─── Plugin process registry ─────────────────────────────────────────────────
# Maps script_name → Popen object so we can kill/restart cleanly
_plugin_procs: dict[str, subprocess.Popen] = {}


def _kill_plugin_proc(script_name: str):
    """
    Forcibly terminate a tracked plugin process and remove it from the registry.
    Uses taskkill on Windows for a proper process-tree kill; SIGTERM elsewhere.
    """
    proc = _plugin_procs.pop(script_name, None)
    if proc is None:
        return
    try:
        if proc.poll() is None:          # still alive
            if sys.platform == "win32":
                subprocess.call(
                    ["taskkill", "/F", "/T", "/PID", str(proc.pid)],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                )
            else:
                import signal, os
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                except ProcessLookupError:
                    proc.terminate()
            proc.wait(timeout=5)
    except Exception:
        pass


def kill_all_plugins():
    """Shut down every running plugin process — called on app teardown."""
    for name in list(_plugin_procs.keys()):
        _kill_plugin_proc(name)


# ─── Debug log capture ────────────────────────────────────────────────────────
def _start_debug_readers(script_name: str, proc: subprocess.Popen, log_cb):
    """
    Spawns background threads that read a plugin's stdout/stderr line by line
    and forward each line into the manager's log, auto-tagging anything that
    looks like an error or warning.
    """
    def _reader(stream, default_level: str):
        try:
            for raw in iter(stream.readline, ""):
                line = raw.rstrip("\n")
                if not line:
                    continue
                low = line.lower()
                if "traceback" in low or "exception" in low or "error" in low:
                    level = "ERROR"
                elif "warn" in low:
                    level = "WARNING"
                else:
                    level = default_level
                log_cb(f"[{script_name}] {line}", level)
        except Exception:
            pass
        finally:
            try:
                stream.close()
            except Exception:
                pass

    threading.Thread(target=_reader, args=(proc.stdout, "MSG"),   daemon=True).start()
    threading.Thread(target=_reader, args=(proc.stderr, "ERROR"), daemon=True).start()


# ─── Plugin launcher ──────────────────────────────────────────────────────────
def launch_feature_script(script_name: str, token: str, state: str,
                          debug: bool = False, log_cb=None):
    """
    Launch a feature script in a minimized terminal window.
    Passes --token and --state arguments to the script.
    Any previous instance of the same script is killed first.

    If debug=True (and a log_cb is provided), the script's console window is
    suppressed and its stdout/stderr are piped straight into the manager's
    log panel instead — including anything it prints and any error/warning
    it raises.
    """
    script_path = PROJECT_DIR / script_name
    if not script_path.exists():
        return False, f"Script not found: {script_path}"

    # Always kill any leftover instance before (re)launching
    _kill_plugin_proc(script_name)

    # Force-killing a plugin (taskkill /F) bypasses its atexit/finally
    # cleanup, so a "don't start twice" lock file it wrote on its previous
    # run can be left behind pointing at a PID that no longer exists. Since
    # we're about to start a brand-new instance anyway, clear that stale
    # lock proactively so the plugin doesn't mistake it for a sibling
    # instance and refuse to actually start.
    stale_pid_file = PROJECT_DIR / f"{script_path.stem}.pid"
    try:
        stale_pid_file.unlink(missing_ok=True)
    except Exception:
        pass

    capture = debug and log_cb is not None and state == "on"

    try:
        kwargs = {
            "args": [sys.executable, str(script_path),
                     "--token", token,
                     "--state", state],
        }

        # Force UTF-8 stdio in the child process. Without this, Python falls
        # back to the Windows console codepage (often cp1252) whenever stdout
        # isn't a real terminal, and any print() containing a non-ASCII
        # character (→, ✓, emoji, etc.) raises UnicodeEncodeError and kills
        # the plugin outright.
        child_env = os.environ.copy()
        child_env["PYTHONIOENCODING"] = "utf-8"
        child_env["PYTHONUTF8"]       = "1"
        kwargs["env"] = child_env

        if capture:
            kwargs["stdout"]    = subprocess.PIPE
            kwargs["stderr"]    = subprocess.PIPE
            kwargs["text"]      = True
            kwargs["encoding"]  = "utf-8"
            kwargs["errors"]    = "replace"
            kwargs["bufsize"]   = 1

        if sys.platform == "win32":
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            if capture:
                # No visible console needed — output is going to the log instead
                si.wShowWindow = 0   # SW_HIDE
                kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            else:
                si.wShowWindow = 6   # SW_MINIMIZE
                kwargs["creationflags"] = subprocess.CREATE_NEW_CONSOLE
            kwargs["startupinfo"] = si
        else:
            kwargs["start_new_session"] = True

        proc = subprocess.Popen(**kwargs)

        # Only track the process when we're launching it (state == "on")
        # When turning off we just want a clean kill, not a new entry
        if state == "on":
            _plugin_procs[script_name] = proc

        if capture:
            _start_debug_readers(script_name, proc, log_cb)

        return True, "OK"
    except Exception as e:
        return False, str(e)

# ─── Discord bot wrapper ──────────────────────────────────────────────────────
class BotWrapper:
    def __init__(self, log_cb):
        self.log_cb       = log_cb
        self.bot          = None
        self.loop         = asyncio.new_event_loop()
        self.thread       = None
        self.running      = False
        self.info         = {}
        self.lockdown     = False   # ← lockdown state flag
        self._token       = ""
        self.connected_at = None    # ← timestamp set once on_ready fires

        # Chat feature: live update subscribers, keyed by channel id.
        # Each maps channel_id -> list of callables to notify.
        self._chat_listeners  = {}
        self._voice_listeners = {}

    # ── Public API ────────────────────────────────────────────────────────────
    def start(self, token: str):
        if self.running:
            return
        self._token = token
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        self.running = True

    def stop(self):
        if self.loop and self.loop.is_running():
            fut = asyncio.run_coroutine_threadsafe(self._shutdown(), self.loop)
            try:
                fut.result(timeout=10)       # wait for bot.close() to finish
            except Exception:
                pass
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=8)      # wait for the thread to exit

    def set_lockdown(self, active: bool):
        """Toggle lockdown mode (thread-safe)."""
        self.lockdown = active
        state = "ENABLED 🔒" if active else "DISABLED 🔓"
        self.log_cb(f"Lockdown {state}", "WARNING" if active else "SUCCESS")

    # ── Chat feature: live-update subscriptions ───────────────────────────────
    def register_chat_listener(self, channel_id: int, callback):
        self._chat_listeners.setdefault(channel_id, []).append(callback)

    def unregister_chat_listener(self, channel_id: int, callback):
        lst = self._chat_listeners.get(channel_id)
        if lst and callback in lst:
            lst.remove(callback)

    def register_voice_listener(self, channel_id: int, callback):
        self._voice_listeners.setdefault(channel_id, []).append(callback)

    def unregister_voice_listener(self, channel_id: int, callback):
        lst = self._voice_listeners.get(channel_id)
        if lst and callback in lst:
            lst.remove(callback)

    # ── Chat feature: run a coroutine on the bot's loop from the UI thread ────
    def run_coro(self, coro, timeout: float = 10):
        if not self.loop or not self.loop.is_running():
            raise RuntimeError("Bot is not connected.")
        fut = asyncio.run_coroutine_threadsafe(coro, self.loop)
        return fut.result(timeout=timeout)

    # ── Chat feature: channel tree snapshot ────────────────────────────────────
    def get_guild_channel_tree(self):
        """
        Snapshot of every guild's categories/channels, safe to call from the
        UI thread (just reads cached discord.py objects, no network calls).
        """
        if not self.bot:
            return []

        def _chan_dict(ch):
            if isinstance(ch, discord.VoiceChannel):
                return {"id": ch.id, "name": ch.name, "type": "voice",
                        "member_count": len(ch.members)}
            if isinstance(ch, discord.TextChannel):
                return {"id": ch.id, "name": ch.name, "type": "text",
                        "topic": ch.topic or ""}
            return None

        out = []
        for g in self.bot.guilds:
            categories = []
            for cat in g.categories:
                chans = [d for d in (_chan_dict(c) for c in cat.channels) if d]
                categories.append({"id": cat.id, "name": cat.name, "channels": chans})
            uncategorized = [
                d for d in (_chan_dict(c) for c in g.channels if c.category is None) if d
            ]
            out.append({
                "guild_id":      g.id,
                "guild_name":    g.name,
                "categories":    categories,
                "uncategorized": uncategorized,
            })
        return out

    # ── Chat feature: message history / channel & member info ────────────────
    async def _fetch_history(self, channel_id: int, limit: int):
        channel = self.bot.get_channel(channel_id) or await self.bot.fetch_channel(channel_id)
        msgs = [_serialize_message(m) async for m in channel.history(limit=limit)]
        msgs.reverse()
        return msgs

    def fetch_channel_history(self, channel_id: int, limit: int = 50):
        return self.run_coro(self._fetch_history(channel_id, limit))

    def get_voice_channel_members(self, channel_id: int):
        channel = self.bot.get_channel(channel_id) if self.bot else None
        if channel is None:
            return []
        return [_serialize_member(m) for m in channel.members]

    def get_member_info(self, guild_id: int, user_id: int):
        guild = self.bot.get_guild(guild_id) if self.bot else None
        member = guild.get_member(user_id) if guild else None
        return _serialize_member(member) if member else None

    # ── Chat feature: send a message as the bot ───────────────────────────────
    async def _send_message(self, channel_id: int, content: str):
        channel = self.bot.get_channel(channel_id) or await self.bot.fetch_channel(channel_id)
        embed = discord.Embed(
            title="📋  Staff Message",
            description=content,
            colour=discord.Colour.from_rgb(140, 100, 220),
        )
        embed.set_footer(text="Sent via Hexy's Bot Manager")
        await channel.send(embed=embed)

    def send_message(self, channel_id: int, content: str):
        return self.run_coro(self._send_message(channel_id, content))

    # ── Chat feature: moderation actions ──────────────────────────────────────
    async def _kick_member(self, guild_id, user_id, reason):
        guild  = self.bot.get_guild(guild_id)
        member = guild.get_member(user_id)
        await member.kick(reason=reason)

    async def _ban_member(self, guild_id, user_id, reason, unban_after_seconds):
        guild  = self.bot.get_guild(guild_id)
        member = guild.get_member(user_id)
        await member.ban(reason=reason)
        if unban_after_seconds:
            banned_at = discord.utils.utcnow()
            unban_at  = banned_at + timedelta(seconds=unban_after_seconds)
            _add_schedule_entry(guild_id, user_id, unban_at, banned_at)
            self._schedule_unban(guild, user_id, unban_at)

    def _schedule_unban(self, guild, user_id: int, unban_at: datetime):
        """
        Schedules (or immediately performs, if overdue) an auto-unban for a
        specific absolute UTC datetime. Used both right after a fresh ban
        and when reloading pending unbans from disk on reconnect.
        """
        async def _later():
            remaining = (unban_at - discord.utils.utcnow()).total_seconds()
            if remaining > 0:
                await asyncio.sleep(remaining)
            try:
                await guild.unban(discord.Object(id=user_id),
                                  reason="Temporary ban expired")
                self.log_cb(f"⏱ Temporary ban expired — unbanned user {user_id} "
                           f"in {guild.name}", "INFO")
            except discord.NotFound:
                pass   # already unbanned (e.g. manually) — nothing to do
            except Exception as e:
                self.log_cb(f"Could not auto-unban {user_id}: {e}", "ERROR")
            finally:
                _remove_schedule_entry(guild.id, user_id)
        asyncio.create_task(_later())

    def reschedule_pending_unbans(self):
        """
        Called once after the bot connects: reloads any temp-bans that were
        still pending when the app last closed. Overdue ones unban right
        away; the rest resume counting down from the exact stored
        expiry — no guesswork about how much time has actually passed.
        """
        entries = _load_schedule()
        if not entries:
            return
        restored = 0
        for e in entries:
            guild = self.bot.get_guild(e["guild_id"])
            if guild is None:
                continue   # bot's no longer in that server — drop silently
            unban_at = datetime.fromisoformat(e["unban_at"])
            self._schedule_unban(guild, e["user_id"], unban_at)
            restored += 1
        if restored:
            self.log_cb(f"⏱ Restored {restored} pending temp-ban timer(s) "
                       f"from disk", "INFO")

    async def _timeout_member(self, guild_id, user_id, seconds, reason):
        guild  = self.bot.get_guild(guild_id)
        member = guild.get_member(user_id)
        until  = discord.utils.utcnow() + timedelta(seconds=seconds) if seconds else None
        await member.timeout(until, reason=reason)

    def kick_member(self, guild_id, user_id, reason="Kicked via Hexy's Bot Manager"):
        return self.run_coro(self._kick_member(guild_id, user_id, reason))

    def ban_member(self, guild_id, user_id, reason="Banned via Hexy's Bot Manager",
                   unban_after_seconds=None):
        return self.run_coro(
            self._ban_member(guild_id, user_id, reason, unban_after_seconds))

    def timeout_member(self, guild_id, user_id, seconds,
                       reason="Timed out via Hexy's Bot Manager"):
        return self.run_coro(self._timeout_member(guild_id, user_id, seconds, reason))

    @property
    def token(self):
        return self._token

    # ── Internals ─────────────────────────────────────────────────────────────
    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_until_complete(self._start_bot())

    async def _start_bot(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members          = True

        self.bot = commands.Bot(command_prefix="!", intents=intents)

        # ── Global command check: block all commands during lockdown ──────────
        @self.bot.check
        async def global_lockdown_check(ctx):
            if self.lockdown:
                self.log_cb(
                    f"[LOCKDOWN] Blocked command '{ctx.command}' "
                    f"from {ctx.author}", "WARNING")
                return False
            return True

        @self.bot.event
        async def on_ready():
            self.info = {
                "name":        str(self.bot.user),
                "id":          self.bot.user.id,
                "avatar_url":  str(self.bot.user.display_avatar.url),
                "guild_count": len(self.bot.guilds),
                "ping":        round(self.bot.latency * 1000),
            }
            self.connected_at = time.time()
            self.log_cb(
                f"✓ Logged in as {self.bot.user}  (ID: {self.bot.user.id})",
                "SUCCESS")
            self.log_cb(f"  Serving {len(self.bot.guilds)} server(s)", "INFO")
            self.reschedule_pending_unbans()

        @self.bot.event
        async def on_message(msg):
            # ── Lockdown: silently delete any message the bot sends ───────────
            if self.lockdown and msg.author == self.bot.user:
                try:
                    await msg.delete()
                    self.log_cb(
                        f"[LOCKDOWN] Deleted bot message in #{msg.channel}",
                        "WARNING")
                except discord.Forbidden:
                    self.log_cb(
                        "[LOCKDOWN] No permission to delete message in "
                        f"#{msg.channel}", "ERROR")
                return   # Don't process commands either

            if not msg.author.bot:
                self.log_cb(
                    f"[#{msg.channel}] {msg.author}: {msg.content[:140]}",
                    "MSG")

            listeners = self._chat_listeners.get(msg.channel.id)
            if listeners:
                data = _serialize_message(msg)
                for cb in list(listeners):
                    try:
                        cb(data)
                    except Exception:
                        pass

            await self.bot.process_commands(msg)

        @self.bot.event
        async def on_interaction(interaction: discord.Interaction):
            # Block all slash command interactions during lockdown
            if self.lockdown and interaction.type == discord.InteractionType.application_command:
                self.log_cb(
                    f"[LOCKDOWN] Blocked slash command "
                    f"'/{interaction.data.get('name', '?')}' "
                    f"from {interaction.user}", "WARNING")
                try:
                    await interaction.response.send_message(
                        "🔒 The bot is currently in lockdown.", ephemeral=True)
                except Exception:
                    pass
                return

        @self.bot.event
        async def on_guild_join(g):
            self.log_cb(f"✓ Joined server: {g.name}", "SUCCESS")

        @self.bot.event
        async def on_guild_remove(g):
            self.log_cb(f"⚠  Left server: {g.name}", "WARNING")

        @self.bot.event
        async def on_member_unban(guild, user):
            # Covers a manual unban done straight in Discord, outside the
            # manager — without this, a stale schedule entry would sit in
            # mod_schedule.json forever (harmless, but worth cleaning up).
            _remove_schedule_entry(guild.id, user.id)

        @self.bot.event
        async def on_voice_state_update(member, before, after):
            for ch in (before.channel, after.channel):
                if ch is None:
                    continue
                listeners = self._voice_listeners.get(ch.id)
                if listeners:
                    data = [_serialize_member(m) for m in ch.members]
                    for cb in list(listeners):
                        try:
                            cb(data)
                        except Exception:
                            pass

        @self.bot.event
        async def on_command_error(ctx, error):
            if isinstance(error, commands.CheckFailure) and self.lockdown:
                return   # Already logged by the global check
            self.log_cb(f"Command error: {error}", "ERROR")

        try:
            await self.bot.start(self._token)
        except discord.LoginFailure:
            self.log_cb("✗ Invalid token — please re-enter your bot token.",
                        "ERROR")
            self.running = False
        except Exception as e:
            self.log_cb(f"✗ Bot error: {e}", "ERROR")
            self.running = False

    async def _shutdown(self):
        self.bot and await self.bot.close()

    def get_guilds(self):
        """
        Snapshot every guild the bot is currently in.
        Safe to call from the UI thread — just reads already-cached
        discord.py objects, no network/coroutine calls involved.
        """
        if not self.bot:
            return []
        out = []
        for g in self.bot.guilds:
            out.append({
                "id":           g.id,
                "name":         g.name,
                "icon_url":     str(g.icon.url) if g.icon else None,
                "member_count": g.member_count or 0,
            })
        return out


# ─── Lockdown double-confirm dialog ──────────────────────────────────────────
class LockdownDialog(tk.Toplevel):
    """
    Two-stage confirmation dialog for activating lockdown.
    .result is True if the user confirmed both stages, False otherwise.
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.result = False
        self._stage = 1

        self.title("Lockdown Bot — Confirmation")
        self.geometry("480x290")
        self.resizable(False, False)
        self.configure(bg=BG_DARK)
        self.grab_set()
        self.focus_set()

        # Centre over parent
        self.update_idletasks()
        px = parent.winfo_x() + parent.winfo_width()  // 2 - 240
        py = parent.winfo_y() + parent.winfo_height() // 2 - 145
        self.geometry(f"+{px}+{py}")

        self._build()
        self.wait_window()

    def _build(self):
        # Clear any existing widgets
        for w in self.winfo_children():
            w.destroy()

        if self._stage == 1:
            icon_text  = "⚠"
            icon_color = WARNING
            title_text = "Activate Lockdown Mode?"
            body_text  = (
                "Lockdown Mode will immediately:\n\n"
                "  •  Delete every message the bot attempts to send\n"
                "  •  Block all prefix commands (! commands)\n"
                "  •  Block all slash commands with a lockdown notice\n\n"
                "The bot will stay online but will be completely silent\n"
                "and unresponsive until you turn Lockdown off."
            )
            confirm_label = "Yes, activate lockdown"
            confirm_color = WARNING
        else:
            icon_text  = "🔒"
            icon_color = LOCK_RED
            title_text = "Are you absolutely sure?"
            body_text  = (
                "This is your final warning.\n\n"
                "Once activated, your bot will stop responding\n"
                "to everything across ALL servers it is in.\n\n"
                "Click  \"Lock it down\"  to proceed."
            )
            confirm_label = "Lock it down"
            confirm_color = LOCK_RED

        tk.Label(self, text=icon_text, bg=BG_DARK, fg=icon_color,
                 font=("Segoe UI", 32)).pack(pady=(22, 4))

        tk.Label(self, text=title_text, bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 14, "bold")).pack()

        tk.Label(self, text=body_text, bg=BG_DARK, fg=TXT_SEC,
                 font=("Segoe UI", 9), justify="left").pack(
            padx=30, pady=(10, 18))

        btn_row = tk.Frame(self, bg=BG_DARK)
        btn_row.pack()

        tk.Button(btn_row, text="Cancel",
                  bg=BG_CARD, fg=TXT_SEC,
                  activebackground=BORDER, activeforeground=TXT_PRI,
                  font=("Segoe UI", 10), relief="flat",
                  cursor="hand2", padx=18, pady=7,
                  command=self.destroy).pack(side="left", padx=6)

        tk.Button(btn_row, text=confirm_label,
                  bg=confirm_color, fg="#ffffff",
                  activebackground="#ff4060",
                  activeforeground="#ffffff",
                  font=("Segoe UI", 10, "bold"), relief="flat",
                  cursor="hand2", padx=18, pady=7,
                  command=self._confirm).pack(side="left", padx=6)

    def _confirm(self):
        if self._stage == 1:
            self._stage = 2
            self._build()
        else:
            self.result = True
            self.destroy()


# ─── Servers dialog ───────────────────────────────────────────────────────────
class ServersDialog(tk.Toplevel):
    """
    Shows every server (guild) the bot is currently in — icon thumbnail,
    name, member count, and ID. Icons load asynchronously so the dialog
    opens instantly even with many servers.
    """

    def __init__(self, parent, guilds: list):
        super().__init__(parent)
        self.title(f"Servers  •  {len(guilds)} total")
        self.geometry("460x560")
        self.minsize(380, 300)
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        # Centre over parent
        self.update_idletasks()
        px = parent.winfo_x() + parent.winfo_width()  // 2 - 230
        py = parent.winfo_y() + parent.winfo_height() // 2 - 280
        self.geometry(f"+{px}+{py}")

        self._photos = []   # keep PhotoImage refs alive (tkinter needs this)

        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=18, pady=(18, 6))
        tk.Label(hdr, text=f"🌐  Servers  ({len(guilds)})",
                 bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 14, "bold")).pack(side="left")
        tk.Button(hdr, text="✕", bg=BG_DARK, fg=TXT_SEC,
                  activebackground=BG_DARK, activeforeground=TXT_PRI,
                  relief="flat", bd=0, cursor="hand2",
                  font=("Segoe UI", 11), command=self.destroy).pack(side="right")

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=18)

        # ── Scrollable list of guild rows ──────────────────────────────────────
        canvas = tk.Canvas(self, bg=BG_DARK, bd=0, highlightthickness=0)
        sb     = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", pady=8)
        canvas.pack(fill="both", expand=True, padx=(18, 0), pady=8)

        scroll_f = tk.Frame(canvas, bg=BG_DARK)
        win_id   = canvas.create_window((0, 0), window=scroll_f, anchor="nw")

        def _on_resize(e):
            canvas.itemconfig(win_id, width=e.width)
        canvas.bind("<Configure>", _on_resize)

        def _on_frame_configure(_):
            canvas.configure(scrollregion=canvas.bbox("all"))
        scroll_f.bind("<Configure>", _on_frame_configure)

        def _on_wheel(e):
            canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        canvas.bind("<MouseWheel>", _on_wheel)
        scroll_f.bind("<MouseWheel>", _on_wheel)

        if not guilds:
            tk.Label(scroll_f, text="Not currently in any servers.",
                     bg=BG_DARK, fg=TXT_SEC, font=("Segoe UI", 10)).pack(pady=30)
        else:
            for g in sorted(guilds, key=lambda x: x["name"].lower()):
                self._build_guild_row(scroll_f, g)

    def _build_guild_row(self, parent, g: dict):
        row = tk.Frame(parent, bg=BG_CARD,
                       highlightthickness=1, highlightbackground=BORDER)
        row.pack(fill="x", pady=5, padx=(0, 14), ipady=4)

        icon_lbl = tk.Label(row, bg=BG_CARD, width=3, height=2,
                            text="🌐", font=("Segoe UI", 16), fg=TXT_MUT)
        icon_lbl.pack(side="left", padx=12, pady=8)

        info_f = tk.Frame(row, bg=BG_CARD)
        info_f.pack(side="left", fill="both", expand=True, pady=8)

        tk.Label(info_f, text=g["name"], bg=BG_CARD, fg=TXT_PRI,
                 font=("Segoe UI", 11, "bold"), anchor="w",
                 wraplength=280, justify="left").pack(anchor="w")
        tk.Label(info_f,
                 text=f"👥 {g['member_count']:,} member(s)   •   ID {g['id']}",
                 bg=BG_CARD, fg=TXT_SEC, font=("Segoe UI", 8),
                 anchor="w").pack(anchor="w", pady=(2, 0))

        if g.get("icon_url"):
            threading.Thread(
                target=self._load_guild_icon,
                args=(g["icon_url"], icon_lbl),
                daemon=True,
            ).start()

    def _load_guild_icon(self, url: str, label: tk.Label):
        """Runs on a background thread; hands the finished image back via .after()."""
        try:
            data = requests.get(url, timeout=6).content
            img  = Image.open(BytesIO(data)).convert("RGBA").resize((48, 48), Image.LANCZOS)
            mask = Image.new("L", (48, 48), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, 47, 47), fill=255)
            img.putalpha(mask)
            photo = ImageTk.PhotoImage(img)
        except Exception:
            return

        def _apply():
            self._photos.append(photo)   # prevent garbage collection
            label.config(image=photo, text="", width=48, height=48)

        try:
            self.after(0, _apply)
        except tk.TclError:
            pass   # dialog was closed before the icon finished loading


# ─── Duration picker (used by Timeout and temporary Ban) ─────────────────────
class DurationPickerDialog(tk.Toplevel):
    """
    Small popup for picking a duration. .result is either an int (seconds),
    None (meaning "permanent" — only offered when allow_permanent=True), or
    False if the user cancelled.
    """
    PRESETS = [
        ("60 sec",  60), ("5 min",  300), ("10 min", 600),
        ("1 hour",  3600), ("1 day", 86400), ("1 week", 604800),
    ]

    def __init__(self, parent, title: str, allow_permanent: bool = False):
        super().__init__(parent)
        self.result = False
        self.title(title)
        self.configure(bg=BG_DARK)
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        tk.Label(self, text=title, bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 12, "bold")).pack(padx=24, pady=(20, 12))

        grid = tk.Frame(self, bg=BG_DARK)
        grid.pack(padx=24)
        for i, (label, secs) in enumerate(self.PRESETS):
            tk.Button(grid, text=label, width=10,
                     bg=BG_CARD, fg=TXT_PRI,
                     activebackground=ACCENT, activeforeground="#ffffff",
                     font=("Segoe UI", 9), relief="flat", cursor="hand2",
                     pady=8, command=lambda s=secs: self._pick(s)
                     ).grid(row=i // 3, column=i % 3, padx=4, pady=4)

        custom_f = tk.Frame(self, bg=BG_DARK)
        custom_f.pack(padx=24, pady=(10, 4), fill="x")
        tk.Label(custom_f, text="Custom (minutes):", bg=BG_DARK, fg=TXT_SEC,
                 font=("Segoe UI", 9)).pack(side="left")
        self._custom_var = tk.StringVar()
        tk.Entry(custom_f, textvariable=self._custom_var, width=8,
                 bg=BG_CARD, fg=TXT_PRI, insertbackground=TXT_PRI,
                 relief="flat").pack(side="left", padx=8)
        tk.Button(custom_f, text="Use", bg=ACCENT, fg="#ffffff",
                 activebackground=ACCENT_LT, relief="flat", cursor="hand2",
                 font=("Segoe UI", 9, "bold"), padx=10,
                 command=self._pick_custom).pack(side="left")

        btn_row = tk.Frame(self, bg=BG_DARK)
        btn_row.pack(pady=(14, 20))
        if allow_permanent:
            tk.Button(btn_row, text="Permanent", bg=LOCK_RED, fg="#ffffff",
                      activebackground="#ff4060", relief="flat", cursor="hand2",
                      font=("Segoe UI", 9, "bold"), padx=14, pady=6,
                      command=lambda: self._pick(None)).pack(side="left", padx=6)
        tk.Button(btn_row, text="Cancel", bg=BG_CARD, fg=TXT_SEC,
                  activebackground=BORDER, relief="flat", cursor="hand2",
                  font=("Segoe UI", 9), padx=14, pady=6,
                  command=self.destroy).pack(side="left", padx=6)

        self.update_idletasks()
        px = parent.winfo_x() + parent.winfo_width()  // 2 - self.winfo_width()  // 2
        py = parent.winfo_y() + parent.winfo_height() // 2 - self.winfo_height() // 2
        self.geometry(f"+{px}+{py}")
        self.wait_window()

    def _pick(self, seconds):
        self.result = seconds
        self.destroy()

    def _pick_custom(self):
        try:
            minutes = float(self._custom_var.get())
            if minutes <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning(APP_NAME, "Enter a positive number of minutes.")
            return
        self._pick(int(minutes * 60))


# ─── User profile / moderation dialog ─────────────────────────────────────────
class UserProfileDialog(tk.Toplevel):
    """
    Shows a member's avatar, name, join date, role — plus Kick / Timeout /
    Ban moderation buttons. All Discord calls run on a background thread so
    the UI never freezes while waiting on the API.
    """

    def __init__(self, parent, bot_wrapper, guild_id: int, user_id: int, log_cb):
        super().__init__(parent)
        self.bot_wrapper = bot_wrapper
        self.guild_id    = guild_id
        self.user_id     = user_id
        self.log_cb      = log_cb
        self._photo      = None

        self.title("Member Profile")
        self.geometry("360x420")
        self.resizable(False, False)
        self.configure(bg=BG_DARK)
        self.transient(parent)
        self.grab_set()

        self.update_idletasks()
        px = parent.winfo_x() + parent.winfo_width()  // 2 - 180
        py = parent.winfo_y() + parent.winfo_height() // 2 - 210
        self.geometry(f"+{px}+{py}")

        info = bot_wrapper.get_member_info(guild_id, user_id)
        if info is None:
            tk.Label(self, text="This member could not be found\n"
                                "(they may have left the server).",
                     bg=BG_DARK, fg=TXT_SEC, font=("Segoe UI", 10),
                     justify="center").pack(expand=True)
            return
        self._info = info

        self._av_lbl = tk.Label(self, bg=BG_DARK, text="👤",
                                font=("Segoe UI", 30), fg=TXT_MUT)
        self._av_lbl.pack(pady=(24, 6))
        threading.Thread(target=self._load_avatar,
                         args=(info["avatar_url"],), daemon=True).start()

        tk.Label(self, text=info["display_name"], bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 14, "bold")).pack()
        tk.Label(self, text=info["name"], bg=BG_DARK, fg=TXT_SEC,
                 font=("Segoe UI", 9)).pack(pady=(0, 10))

        detail_f = tk.Frame(self, bg=BG_CARD, highlightthickness=1,
                            highlightbackground=BORDER)
        detail_f.pack(fill="x", padx=24, pady=6)
        for label, val in (
            ("User ID",   str(info["id"])),
            ("Joined",    info["joined_at"]),
            ("Top Role",  info["top_role"]),
            ("Bot",       "Yes" if info["is_bot"] else "No"),
        ):
            row = tk.Frame(detail_f, bg=BG_CARD)
            row.pack(fill="x", padx=12, pady=4)
            tk.Label(row, text=label, bg=BG_CARD, fg=TXT_MUT,
                     font=("Segoe UI", 8), width=10, anchor="w").pack(side="left")
            tk.Label(row, text=val, bg=BG_CARD, fg=TXT_PRI,
                     font=("Segoe UI", 8, "bold"), anchor="w").pack(side="left")

        btn_f = tk.Frame(self, bg=BG_DARK)
        btn_f.pack(pady=18)
        tk.Button(btn_f, text="⏱  Timeout", bg=WARNING, fg="#1a1a1a",
                  activebackground="#ffb060", relief="flat", cursor="hand2",
                  font=("Segoe UI", 9, "bold"), padx=14, pady=8,
                  command=self._do_timeout).grid(row=0, column=0, padx=4)
        tk.Button(btn_f, text="👢  Kick", bg="#c07030", fg="#ffffff",
                  activebackground="#e08840", relief="flat", cursor="hand2",
                  font=("Segoe UI", 9, "bold"), padx=14, pady=8,
                  command=self._do_kick).grid(row=0, column=1, padx=4)
        tk.Button(btn_f, text="🔨  Ban", bg=LOCK_RED, fg="#ffffff",
                  activebackground="#ff4060", relief="flat", cursor="hand2",
                  font=("Segoe UI", 9, "bold"), padx=14, pady=8,
                  command=self._do_ban).grid(row=0, column=2, padx=4)

        self._status_lbl = tk.Label(self, text="", bg=BG_DARK, fg=TXT_SEC,
                                    font=("Segoe UI", 8), wraplength=300)
        self._status_lbl.pack(pady=(0, 10))

    def _load_avatar(self, url):
        try:
            data = requests.get(url, timeout=6).content
            img  = Image.open(BytesIO(data)).convert("RGBA").resize((88, 88), Image.LANCZOS)
            mask = Image.new("L", (88, 88), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, 87, 87), fill=255)
            img.putalpha(mask)
            photo = ImageTk.PhotoImage(img)
        except Exception:
            return

        def _apply():
            self._photo = photo
            self._av_lbl.config(image=photo, text="")
        try:
            self.after(0, _apply)
        except tk.TclError:
            pass

    def _set_status(self, text, ok=True):
        try:
            self._status_lbl.config(text=text, fg=SUCCESS if ok else ERR)
        except tk.TclError:
            pass

    def _do_kick(self):
        if not messagebox.askyesno(APP_NAME,
                                   f"Kick {self._info['display_name']}?"):
            return
        self._set_status("Kicking…")
        threading.Thread(target=self._run_kick, daemon=True).start()

    def _run_kick(self):
        try:
            self.bot_wrapper.kick_member(self.guild_id, self.user_id)
            self.log_cb(f"👢 Kicked {self._info['name']}", "WARNING")
            self.after(0, self._set_status, "Kicked.", True)
        except Exception as e:
            self.log_cb(f"Kick failed for {self._info['name']}: {e}", "ERROR")
            self.after(0, self._set_status, f"Failed: {e}", False)

    def _do_timeout(self):
        dlg = DurationPickerDialog(self, "Timeout duration")
        if dlg.result is False or dlg.result is None:
            return
        seconds = dlg.result
        self._set_status("Applying timeout…")
        threading.Thread(target=self._run_timeout, args=(seconds,), daemon=True).start()

    def _run_timeout(self, seconds):
        try:
            self.bot_wrapper.timeout_member(self.guild_id, self.user_id, seconds)
            mins = seconds // 60
            self.log_cb(f"⏱ Timed out {self._info['name']} for {mins} min", "WARNING")
            self.after(0, self._set_status, f"Timed out for {mins} min.", True)
        except Exception as e:
            self.log_cb(f"Timeout failed for {self._info['name']}: {e}", "ERROR")
            self.after(0, self._set_status, f"Failed: {e}", False)

    def _do_ban(self):
        dlg = DurationPickerDialog(self, "Ban duration", allow_permanent=True)
        if dlg.result is False:
            return
        seconds = dlg.result   # None == permanent
        label = "permanently" if seconds is None else f"for {seconds // 60} min"
        if not messagebox.askyesno(APP_NAME,
                                   f"Ban {self._info['display_name']} {label}?"):
            return
        self._set_status("Banning…")
        threading.Thread(target=self._run_ban, args=(seconds,), daemon=True).start()

    def _run_ban(self, seconds):
        try:
            self.bot_wrapper.ban_member(self.guild_id, self.user_id,
                                        unban_after_seconds=seconds)
            label = "permanently" if seconds is None else f"for {seconds // 60} min"
            self.log_cb(f"🔨 Banned {self._info['name']} {label}", "ERROR")
            self.after(0, self._set_status, f"Banned {label}.", True)
        except Exception as e:
            self.log_cb(f"Ban failed for {self._info['name']}: {e}", "ERROR")
            self.after(0, self._set_status, f"Failed: {e}", False)


# ─── Live text-channel viewer ─────────────────────────────────────────────────
class ChatWindow(tk.Toplevel):
    """
    Shows a text channel's recent history plus new messages as they arrive
    live. Clicking a username opens that member's profile/moderation dialog.
    """

    def __init__(self, parent, bot_wrapper, guild_id, channel_id,
                channel_name, topic, log_cb):
        super().__init__(parent)
        self.bot_wrapper = bot_wrapper
        self.guild_id    = guild_id
        self.channel_id  = channel_id
        self.log_cb      = log_cb
        self._name_tag_n = 0

        self.title(f"#{channel_name}")
        self.geometry("560x620")
        self.minsize(400, 300)
        self.configure(bg=BG_DARK)
        self.transient(parent)

        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=16, pady=(16, 4))
        tk.Label(hdr, text=f"#  {channel_name}", bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 13, "bold")).pack(anchor="w")
        if topic:
            tk.Label(hdr, text=topic, bg=BG_DARK, fg=TXT_SEC,
                     font=("Segoe UI", 8), wraplength=520,
                     justify="left").pack(anchor="w")

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16, pady=(6, 0))

        self._loading_lbl = tk.Label(self, text="Loading message history…",
                                     bg=BG_DARK, fg=TXT_SEC, font=("Segoe UI", 8))
        self._loading_lbl.pack(anchor="w", padx=16, pady=(6, 0))

        log_f = tk.Frame(self, bg=LOG_BG)
        log_f.pack(fill="both", expand=True, padx=16, pady=10)
        sb = ttk.Scrollbar(log_f, orient="vertical")
        sb.pack(side="right", fill="y")
        self._text = tk.Text(log_f, bg=LOG_BG, fg=TXT_PRI, font=("Segoe UI", 9),
                             relief="flat", bd=0, wrap="word", cursor="arrow",
                             state="disabled", yscrollcommand=sb.set)
        self._text.pack(fill="both", expand=True)
        sb.config(command=self._text.yview)
        self._text.tag_configure("TIME", foreground=TXT_MUT, font=("Segoe UI", 8))
        self._text.tag_configure("CONTENT", foreground=TXT_PRI)

        # ── Send bar: post a message to this channel as the bot ────────────────
        send_f = tk.Frame(self, bg=BG_DARK)
        send_f.pack(side="bottom", fill="x", padx=16, pady=(0, 16))
        self._send_var = tk.StringVar()
        entry = tk.Entry(send_f, textvariable=self._send_var,
                         bg=BG_CARD, fg=TXT_PRI, insertbackground=TXT_PRI,
                         relief="flat", font=("Segoe UI", 9))
        entry.pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 8))
        entry.bind("<Return>", lambda e: self._send())
        self._send_btn = tk.Button(send_f, text="Send", bg=ACCENT, fg="#ffffff",
                                   activebackground=ACCENT_LT, relief="flat",
                                   cursor="hand2", font=("Segoe UI", 9, "bold"),
                                   padx=14, pady=6, command=self._send)
        self._send_btn.pack(side="left")

        threading.Thread(target=self._load_history, daemon=True).start()
        self.bot_wrapper.register_chat_listener(channel_id, self._on_new_message)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _load_history(self):
        try:
            msgs = self.bot_wrapper.fetch_channel_history(self.channel_id, limit=50)
        except Exception as e:
            self.after(0, lambda: self._loading_lbl.config(text=f"Could not load history: {e}"))
            return
        self.after(0, self._render_history, msgs)

    def _render_history(self, msgs):
        try:
            self._loading_lbl.destroy()
        except tk.TclError:
            return
        for m in msgs:
            self._append_message(m)

    def _on_new_message(self, data):
        self.after(0, self._append_message, data)

    def _append_message(self, data):
        try:
            self._text.config(state="normal")
            self._text.insert("end", f"[{data['created_at']}]  ", "TIME")

            tag = f"user_{self._name_tag_n}"
            self._name_tag_n += 1
            self._text.tag_configure(tag, foreground=ACCENT_LT,
                                     font=("Segoe UI", 9, "bold"))
            self._text.tag_bind(tag, "<Button-1>",
                                lambda e, uid=data["author_id"]: self._open_profile(uid))
            self._text.tag_bind(tag, "<Enter>", lambda e: self._text.config(cursor="hand2"))
            self._text.tag_bind(tag, "<Leave>", lambda e: self._text.config(cursor="arrow"))
            self._text.insert("end", data["author_name"], tag)

            self._text.insert("end", f":  {data['content']}\n", "CONTENT")
            self._text.config(state="disabled")
            self._text.see("end")
        except tk.TclError:
            pass   # window was closed mid-update

    def _open_profile(self, user_id):
        UserProfileDialog(self, self.bot_wrapper, self.guild_id, user_id, self.log_cb)

    def _send(self):
        text = self._send_var.get().strip()
        if not text:
            return
        self._send_var.set("")
        self._send_btn.config(state="disabled", text="…")
        threading.Thread(target=self._do_send, args=(text,), daemon=True).start()

    def _do_send(self, text):
        try:
            self.bot_wrapper.send_message(self.channel_id, text)
            self.log_cb(f"📤 Sent message to #{self.channel_id}: {text[:80]}", "INFO")
        except Exception as e:
            self.log_cb(f"Failed to send message: {e}", "ERROR")
            self.after(0, lambda: messagebox.showerror(
                APP_NAME, f"Failed to send message:\n{e}"))
        finally:
            try:
                self.after(0, lambda: self._send_btn.config(state="normal", text="Send"))
            except tk.TclError:
                pass

    def _on_close(self):
        self.bot_wrapper.unregister_chat_listener(self.channel_id, self._on_new_message)
        self.destroy()


# ─── Live voice-channel viewer ────────────────────────────────────────────────
class VoiceChannelWindow(tk.Toplevel):
    """
    Shows who's currently connected to a voice channel (updates live) plus
    that channel's own text chat. Clicking a connected member opens their
    profile/moderation dialog.
    """

    def __init__(self, parent, bot_wrapper, guild_id, channel_id, channel_name, log_cb):
        super().__init__(parent)
        self.bot_wrapper    = bot_wrapper
        self.guild_id       = guild_id
        self.channel_id     = channel_id
        self.log_cb         = log_cb
        self._member_photos = []
        self._name_tag_n    = 0

        self.title(f"🔊 {channel_name}")
        self.geometry("560x680")
        self.minsize(420, 420)
        self.configure(bg=BG_DARK)
        self.transient(parent)

        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=16, pady=(16, 4))
        tk.Label(hdr, text=f"🔊  {channel_name}", bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 13, "bold")).pack(side="left")
        self._count_lbl = tk.Label(hdr, text="", bg=BG_DARK, fg=TXT_SEC,
                                   font=("Segoe UI", 9))
        self._count_lbl.pack(side="left", padx=10)

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16, pady=(6, 6))
        tk.Label(self, text="Connected members", bg=BG_DARK, fg=ACCENT_LT,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16)

        member_outer = tk.Frame(self, bg=BG_DARK, height=170)
        member_outer.pack(fill="x", padx=16, pady=(4, 10))
        member_outer.pack_propagate(False)
        self._member_f = _make_scrollable(member_outer, BG_DARK)

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16)
        tk.Label(self, text="Voice channel chat", bg=BG_DARK, fg=ACCENT_LT,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=16, pady=(10, 4))

        log_f = tk.Frame(self, bg=LOG_BG)
        log_f.pack(fill="both", expand=True, padx=16, pady=(0, 16))
        sb = ttk.Scrollbar(log_f, orient="vertical")
        sb.pack(side="right", fill="y")
        self._text = tk.Text(log_f, bg=LOG_BG, fg=TXT_PRI, font=("Segoe UI", 9),
                             relief="flat", bd=0, wrap="word", cursor="arrow",
                             state="disabled", yscrollcommand=sb.set)
        self._text.pack(fill="both", expand=True)
        sb.config(command=self._text.yview)
        self._text.tag_configure("TIME", foreground=TXT_MUT, font=("Segoe UI", 8))
        self._text.tag_configure("CONTENT", foreground=TXT_PRI)

        # ── Send bar: post a message to this VC's chat as the bot ──────────────
        send_f = tk.Frame(self, bg=BG_DARK)
        send_f.pack(side="bottom", fill="x", padx=16, pady=(0, 16))
        self._send_var = tk.StringVar()
        entry = tk.Entry(send_f, textvariable=self._send_var,
                         bg=BG_CARD, fg=TXT_PRI, insertbackground=TXT_PRI,
                         relief="flat", font=("Segoe UI", 9))
        entry.pack(side="left", fill="x", expand=True, ipady=6, padx=(0, 8))
        entry.bind("<Return>", lambda e: self._send())
        self._send_btn = tk.Button(send_f, text="Send", bg=ACCENT, fg="#ffffff",
                                   activebackground=ACCENT_LT, relief="flat",
                                   cursor="hand2", font=("Segoe UI", 9, "bold"),
                                   padx=14, pady=6, command=self._send)
        self._send_btn.pack(side="left")

        self._refresh_members(bot_wrapper.get_voice_channel_members(channel_id))
        threading.Thread(target=self._load_history, daemon=True).start()

        self.bot_wrapper.register_voice_listener(channel_id, self._on_voice_update)
        self.bot_wrapper.register_chat_listener(channel_id, self._on_new_message)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── Members panel ──────────────────────────────────────────────────────────
    def _on_voice_update(self, members):
        self.after(0, self._refresh_members, members)

    def _refresh_members(self, members):
        try:
            for w in self._member_f.winfo_children():
                w.destroy()
            self._count_lbl.config(text=f"👥 {len(members)} connected")
            if not members:
                tk.Label(self._member_f, text="No one is currently connected.",
                         bg=BG_DARK, fg=TXT_MUT, font=("Segoe UI", 9)).pack(pady=10)
            for m in members:
                self._build_member_row(m)
        except tk.TclError:
            pass

    def _build_member_row(self, m):
        row = tk.Frame(self._member_f, bg=BG_CARD, highlightthickness=1,
                       highlightbackground=BORDER, cursor="hand2")
        row.pack(fill="x", pady=3, padx=(0, 10))
        av = tk.Label(row, bg=BG_CARD, text="👤", font=("Segoe UI", 14),
                     fg=TXT_MUT, cursor="hand2")
        av.pack(side="left", padx=10, pady=6)
        name_lbl = tk.Label(row, text=m["display_name"], bg=BG_CARD, fg=TXT_PRI,
                            font=("Segoe UI", 9, "bold"), cursor="hand2")
        name_lbl.pack(side="left", pady=6)

        for w in (row, av, name_lbl):
            w.bind("<Button-1>", lambda e, uid=m["id"]: self._open_profile(uid))

        threading.Thread(target=self._load_member_avatar,
                         args=(m["avatar_url"], av), daemon=True).start()

    def _load_member_avatar(self, url, label):
        try:
            data = requests.get(url, timeout=6).content
            img  = Image.open(BytesIO(data)).convert("RGBA").resize((28, 28), Image.LANCZOS)
            mask = Image.new("L", (28, 28), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, 27, 27), fill=255)
            img.putalpha(mask)
            photo = ImageTk.PhotoImage(img)
        except Exception:
            return

        def _apply():
            self._member_photos.append(photo)
            label.config(image=photo, text="")
        try:
            self.after(0, _apply)
        except tk.TclError:
            pass

    # ── VC text chat ───────────────────────────────────────────────────────────
    def _load_history(self):
        try:
            msgs = self.bot_wrapper.fetch_channel_history(self.channel_id, limit=50)
        except Exception:
            return
        self.after(0, self._render_history, msgs)

    def _render_history(self, msgs):
        for m in msgs:
            self._append_message(m)

    def _on_new_message(self, data):
        self.after(0, self._append_message, data)

    def _append_message(self, data):
        try:
            self._text.config(state="normal")
            self._text.insert("end", f"[{data['created_at']}]  ", "TIME")
            tag = f"vcuser_{self._name_tag_n}"
            self._name_tag_n += 1
            self._text.tag_configure(tag, foreground=ACCENT_LT,
                                     font=("Segoe UI", 9, "bold"))
            self._text.tag_bind(tag, "<Button-1>",
                                lambda e, uid=data["author_id"]: self._open_profile(uid))
            self._text.tag_bind(tag, "<Enter>", lambda e: self._text.config(cursor="hand2"))
            self._text.tag_bind(tag, "<Leave>", lambda e: self._text.config(cursor="arrow"))
            self._text.insert("end", data["author_name"], tag)
            self._text.insert("end", f":  {data['content']}\n", "CONTENT")
            self._text.config(state="disabled")
            self._text.see("end")
        except tk.TclError:
            pass

    def _open_profile(self, user_id):
        UserProfileDialog(self, self.bot_wrapper, self.guild_id, user_id, self.log_cb)

    def _send(self):
        text = self._send_var.get().strip()
        if not text:
            return
        self._send_var.set("")
        self._send_btn.config(state="disabled", text="…")
        threading.Thread(target=self._do_send, args=(text,), daemon=True).start()

    def _do_send(self, text):
        try:
            self.bot_wrapper.send_message(self.channel_id, text)
            self.log_cb(f"📤 Sent message to VC #{self.channel_id}: {text[:80]}", "INFO")
        except Exception as e:
            self.log_cb(f"Failed to send message: {e}", "ERROR")
            self.after(0, lambda: messagebox.showerror(
                APP_NAME, f"Failed to send message:\n{e}"))
        finally:
            try:
                self.after(0, lambda: self._send_btn.config(state="normal", text="Send"))
            except tk.TclError:
                pass

    def _on_close(self):
        self.bot_wrapper.unregister_voice_listener(self.channel_id, self._on_voice_update)
        self.bot_wrapper.unregister_chat_listener(self.channel_id, self._on_new_message)
        self.destroy()


# ─── Channel browser (entry point for the "Chat" feature) ────────────────────
class ChannelBrowserDialog(tk.Toplevel):
    """
    Lists every guild's categories and channels. Categories are shown
    already-expanded (not clickable). Clicking a text channel opens a
    ChatWindow; clicking a voice channel opens a VoiceChannelWindow.
    """

    def __init__(self, parent, bot_wrapper, log_cb):
        super().__init__(parent)
        self.bot_wrapper = bot_wrapper
        self.log_cb      = log_cb

        self.title("Channels")
        self.geometry("380x600")
        self.minsize(320, 400)
        self.configure(bg=BG_DARK)
        self.transient(parent)

        hdr = tk.Frame(self, bg=BG_DARK)
        hdr.pack(fill="x", padx=16, pady=(16, 6))
        tk.Label(hdr, text="💬  Channels", bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 14, "bold")).pack(side="left")
        tk.Button(hdr, text="✕", bg=BG_DARK, fg=TXT_SEC, relief="flat", bd=0,
                  cursor="hand2", font=("Segoe UI", 11),
                  command=self.destroy).pack(side="right")

        tk.Frame(self, bg=BORDER, height=1).pack(fill="x", padx=16)

        outer = tk.Frame(self, bg=BG_DARK)
        outer.pack(fill="both", expand=True, padx=(16, 0), pady=10)
        scroll_f = _make_scrollable(outer, BG_DARK)

        tree = bot_wrapper.get_guild_channel_tree()
        if not tree:
            tk.Label(scroll_f, text="Not currently in any servers.",
                     bg=BG_DARK, fg=TXT_SEC, font=("Segoe UI", 10)).pack(pady=30)
        for g in tree:
            self._build_guild_section(scroll_f, g)

    def _build_guild_section(self, parent, g):
        tk.Label(parent, text=g["guild_name"], bg=BG_DARK, fg=ACCENT_LT,
                 font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(6, 2))

        for ch in g["uncategorized"]:
            self._build_channel_row(parent, g["guild_id"], ch, indent=10)

        for cat in g["categories"]:
            tk.Label(parent, text=cat["name"].upper(), bg=BG_DARK, fg=TXT_MUT,
                     font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=6, pady=(8, 2))
            for ch in cat["channels"]:
                self._build_channel_row(parent, g["guild_id"], ch, indent=18)

    def _build_channel_row(self, parent, guild_id, ch, indent):
        icon  = "🔊" if ch["type"] == "voice" else "💬"
        extra = f"   ({ch['member_count']})" if ch["type"] == "voice" else ""
        row = tk.Label(parent, text=f"{icon}  {ch['name']}{extra}",
                       bg=BG_DARK, fg=TXT_SEC, font=("Segoe UI", 9),
                       cursor="hand2", anchor="w")
        row.pack(anchor="w", fill="x", padx=(indent, 6), pady=1)
        row.bind("<Enter>", lambda e: row.config(fg=ACCENT_LT))
        row.bind("<Leave>", lambda e: row.config(fg=TXT_SEC))
        row.bind("<Button-1>", lambda e: self._open_channel(guild_id, ch))

    def _open_channel(self, guild_id, ch):
        if ch["type"] == "voice":
            VoiceChannelWindow(self, self.bot_wrapper, guild_id, ch["id"],
                               ch["name"], self.log_cb)
        else:
            ChatWindow(self, self.bot_wrapper, guild_id, ch["id"],
                      ch["name"], ch.get("topic", ""), self.log_cb)


# ─── Main Application ─────────────────────────────────────────────────────────
class HexysApp(tk.Tk):

    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1180x720")
        self.minsize(960, 600)
        self.configure(bg=BG_DARK)

        # Icons
        self._ico_path = None
        src = find_icon()
        if src:
            self._ico_path = src if src.suffix == ".ico" else to_ico(src)
        if self._ico_path:
            set_taskbar_icon(self, self._ico_path)

        icon_src = find_icon()
        self._moon_lg = circle_photo(icon_src, (110, 110)) if icon_src else None
        self._moon_sm = circle_photo(icon_src, (42,  42))  if icon_src else None

        # State
        self._bot_avatar_photo = None
        self.bot_wrapper       = None

        # Feature toggle states  {feature_index: bool}
        self._feature_states: dict[int, bool] = {
            i: False for i in range(len(FEATURES))
        }
        self._feature_btns: dict[int, tk.Button]   = {}
        self._feature_lamps: dict[int, tk.Label]   = {}
        self._feature_status_lbls: dict[int, tk.Label] = {}
        self._debug_states: dict[int, bool]        = {}
        self._debug_btns: dict[int, tk.Button]      = {}

        cfg = json.loads(CONFIG_FILE.read_text())
        self._saved_token = cfg.get("token", "")

        self._apply_styles()
        self._build_token_screen()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ═══ Styles ═══════════════════════════════════════════════════════════════
    def _apply_styles(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TSeparator", background=BORDER)
        s.configure("Vertical.TScrollbar",
                    background=BG_CARD, troughcolor=LOG_BG,
                    borderwidth=0, arrowsize=12)

    # ═══ Token screen ══════════════════════════════════════════════════════════
    def _build_token_screen(self):
        self._token_frame = tk.Frame(self, bg=BG_DARK)
        self._token_frame.place(relx=.5, rely=.5, anchor="center")

        if self._moon_lg:
            tk.Label(self._token_frame, image=self._moon_lg,
                     bg=BG_DARK).pack(pady=(0, 12))

        tk.Label(self._token_frame, text=APP_NAME,
                 bg=BG_DARK, fg=TXT_PRI,
                 font=("Segoe UI", 28, "bold")).pack()
        tk.Label(self._token_frame, text="Discord Bot Management Suite",
                 bg=BG_DARK, fg=TXT_SEC,
                 font=("Segoe UI", 11)).pack(pady=(2, 30))

        card = tk.Frame(self._token_frame, bg=BG_CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(ipadx=10)

        inner = tk.Frame(card, bg=BG_CARD, padx=36, pady=30)
        inner.pack()

        tk.Label(inner, text="BOT TOKEN", bg=BG_CARD, fg=TXT_SEC,
                 font=("Segoe UI", 8, "bold")).pack(anchor="w")

        ef = tk.Frame(inner, bg=BORDER, padx=1, pady=1)
        ef.pack(fill="x", pady=(4, 0))
        ef2 = tk.Frame(ef, bg=BG_DARK)
        ef2.pack(fill="x")

        self._token_var = tk.StringVar(value=self._saved_token)
        self._token_entry = tk.Entry(
            ef2, textvariable=self._token_var,
            show="•", width=44, bg=BG_DARK, fg=TXT_PRI,
            insertbackground=TXT_PRI, relief="flat",
            font=("Segoe UI", 12), bd=10)
        self._token_entry.pack(side="left", fill="x", expand=True)

        self._show_tok = False
        eye = tk.Label(ef2, text="👁", bg=BG_DARK, fg=TXT_SEC,
                       cursor="hand2", font=("Segoe UI", 13), padx=8)
        eye.pack(side="right")
        eye.bind("<Button-1>", lambda _: self._toggle_token())
        self._eye = eye

        # Security notice
        warn_box = tk.Frame(inner, bg="#1e1000",
                            highlightthickness=1, highlightbackground="#4a3000")
        warn_box.pack(fill="x", pady=(14, 20))
        wi = tk.Frame(warn_box, bg="#1e1000", padx=12, pady=10)
        wi.pack(fill="x")
        tk.Label(wi, text="⚠  Security Notice",
                 bg="#1e1000", fg=WARNING,
                 font=("Segoe UI", 9, "bold")).pack(anchor="w")
        tk.Label(wi,
                 text="Your bot token grants full control over your Discord bot.\n"
                      "Never share it publicly, commit it to version control,\n"
                      "or send it to anyone you do not completely trust.",
                 bg="#1e1000", fg="#c09040",
                 font=("Segoe UI", 8), justify="left").pack(anchor="w", pady=(3, 0))

        tk.Button(inner, text="Connect Bot  →",
                  bg=ACCENT, fg="#ffffff",
                  activebackground=ACCENT_LT, activeforeground="#ffffff",
                  font=("Segoe UI", 12, "bold"), relief="flat",
                  cursor="hand2", padx=28, pady=11,
                  command=self._connect_bot).pack()

        self._token_entry.bind("<Return>", lambda _: self._connect_bot())
        self._token_entry.focus_set()

    def _toggle_token(self):
        self._show_tok = not self._show_tok
        self._token_entry.config(show="" if self._show_tok else "•")
        self._eye.config(fg=ACCENT_LT if self._show_tok else TXT_SEC)

    def _connect_bot(self):
        token = self._token_var.get().strip()
        if not token:
            messagebox.showwarning(APP_NAME, "Please enter your bot token.")
            return

        cfg = json.loads(CONFIG_FILE.read_text())
        cfg["token"] = token
        cfg["last_launch"] = time.strftime("%Y-%m-%d %H:%M:%S")
        CONFIG_FILE.write_text(json.dumps(cfg, indent=2))

        self._token_frame.place_forget()
        self._build_main_ui()

        self.bot_wrapper = BotWrapper(log_cb=self._append_log)
        self.bot_wrapper.start(token)
        self.after(3500, self._poll_bot_info)
        self.after(4000, self._poll_plugin_health)

    # ═══ Main UI ═══════════════════════════════════════════════════════════════
    def _build_main_ui(self):
        self._build_topbar()

        cols = tk.Frame(self, bg=BG_DARK)
        cols.pack(fill="both", expand=True, padx=12, pady=(0, 12))
        cols.columnconfigure(0, weight=0, minsize=246)
        cols.columnconfigure(1, weight=1)
        cols.columnconfigure(2, weight=0, minsize=320)
        cols.rowconfigure(0, weight=1)

        self._build_left(cols).grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self._build_centre(cols).grid(row=0, column=1, sticky="nsew", padx=4)
        self._build_right(cols).grid(row=0, column=2, sticky="nsew", padx=(8, 0))

    def _build_topbar(self):
        bar = tk.Frame(self, bg=BG_PANEL, height=56)
        bar.pack(fill="x")
        bar.pack_propagate(False)

        if self._moon_sm:
            tk.Label(bar, image=self._moon_sm, bg=BG_PANEL).pack(
                side="left", padx=(14, 0), pady=7)

        tk.Label(bar, text=APP_NAME, bg=BG_PANEL, fg=TXT_PRI,
                 font=("Segoe UI", 14, "bold")).pack(side="left", padx=10)

        self._dot = tk.Label(bar, text="●", bg=BG_PANEL,
                              fg=TXT_MUT, font=("Segoe UI", 12))
        self._dot.pack(side="left", padx=(6, 2))
        self._status_lbl = tk.Label(bar, text="Connecting…",
                                     bg=BG_PANEL, fg=TXT_MUT,
                                     font=("Segoe UI", 9))
        self._status_lbl.pack(side="left")

        self._uptime_lbl = tk.Label(bar, text="", bg=BG_PANEL, fg=TXT_MUT,
                                     font=("Segoe UI", 9))
        self._uptime_lbl.pack(side="left", padx=(10, 0))

        tk.Button(bar, text="🌐  Servers",
                  bg=BG_CARD, fg=ACCENT_LT,
                  activebackground=BORDER, activeforeground=ACCENT_LT,
                  font=("Segoe UI", 9, "bold"), relief="flat",
                  cursor="hand2", padx=10, pady=4,
                  command=self._show_servers_dialog).pack(side="right", padx=(0, 8), pady=12)

        tk.Button(bar, text="💬  Chat",
                  bg=BG_CARD, fg=ACCENT_LT,
                  activebackground=BORDER, activeforeground=ACCENT_LT,
                  font=("Segoe UI", 9, "bold"), relief="flat",
                  cursor="hand2", padx=10, pady=4,
                  command=self._show_channel_browser).pack(side="right", padx=(0, 8), pady=12)

        tk.Button(bar, text="⏻  Disconnect",
                  bg="#200010", fg=ERR,
                  activebackground="#300020", activeforeground=ERR,
                  font=("Segoe UI", 9, "bold"), relief="flat",
                  cursor="hand2", padx=10, pady=4,
                  command=self._disconnect).pack(side="right", padx=14, pady=12)

    # ── Left panel ────────────────────────────────────────────────────────────
    def _build_left(self, parent):
        p = tk.Frame(parent, bg=BG_PANEL,
                     highlightthickness=1, highlightbackground=BORDER)

        tk.Label(p, text="Bot Information", bg=BG_PANEL, fg=ACCENT_LT,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(14, 6))
        tk.Frame(p, bg=BORDER, height=1).pack(fill="x", padx=14)

        self._av_lbl = tk.Label(p, bg=BG_PANEL)
        self._av_lbl.pack(pady=(18, 4))

        self._bname = tk.Label(p, text="—", bg=BG_PANEL, fg=TXT_PRI,
                                font=("Segoe UI", 14, "bold"), wraplength=220)
        self._bname.pack()
        self._btag = tk.Label(p, text="", bg=BG_PANEL, fg=TXT_SEC,
                               font=("Segoe UI", 9))
        self._btag.pack(pady=(0, 14))

        tk.Frame(p, bg=BORDER, height=1).pack(fill="x", padx=14)

        info_f = tk.Frame(p, bg=BG_PANEL)
        info_f.pack(fill="x", padx=14, pady=12)
        self._info = {}
        for label, emoji in (("User ID", "🆔"), ("Servers", "🌐"), ("Ping", "📡")):
            row = tk.Frame(info_f, bg=BG_PANEL)
            row.pack(fill="x", pady=5)
            tk.Label(row, text=f"{emoji}  {label}", bg=BG_PANEL, fg=TXT_MUT,
                     font=("Segoe UI", 9), width=14, anchor="w").pack(side="left")
            val = tk.Label(row, text="—", bg=BG_PANEL, fg=TXT_PRI,
                           font=("Segoe UI", 9, "bold"), anchor="w")
            val.pack(side="left", fill="x", expand=True)
            self._info[label] = val

        return p

    # ── Centre panel (features) ───────────────────────────────────────────────
    def _build_centre(self, parent):
        outer = tk.Frame(parent, bg=BG_PANEL,
                         highlightthickness=1, highlightbackground=BORDER)

        tk.Label(outer, text="Features", bg=BG_PANEL, fg=ACCENT_LT,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(14, 6))
        tk.Frame(outer, bg=BORDER, height=1).pack(fill="x", padx=14)

        # Scrollable feature cards
        canvas = tk.Canvas(outer, bg=BG_PANEL, bd=0, highlightthickness=0)
        sb     = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        canvas.pack(fill="both", expand=True, padx=8, pady=8)

        scroll_f = tk.Frame(canvas, bg=BG_PANEL)
        win_id   = canvas.create_window((0, 0), window=scroll_f, anchor="nw")

        def _on_resize(e):
            canvas.itemconfig(win_id, width=e.width)
        canvas.bind("<Configure>", _on_resize)

        def _on_frame_configure(_):
            canvas.configure(scrollregion=canvas.bbox("all"))
        scroll_f.bind("<Configure>", _on_frame_configure)

        # Mouse-wheel scrolling
        def _on_wheel(e):
            canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_wheel)

        if not FEATURES:
            tk.Label(scroll_f, text="No features configured.\nEdit the FEATURES list in the source.",
                     bg=BG_PANEL, fg=TXT_SEC, font=("Segoe UI", 10),
                     justify="center").pack(pady=40)
        else:
            for i, feat in enumerate(FEATURES):
                self._build_feature_card(scroll_f, i, feat)

        return outer

    def _build_feature_card(self, parent, idx: int, feat: dict):
        """Build one feature card with toggle button and status lamp."""
        is_lockdown = feat.get("builtin_key") == "lockdown"

        card = tk.Frame(parent, bg=BG_CARD,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", padx=6, pady=6, ipady=4)

        top_row = tk.Frame(card, bg=BG_CARD)
        top_row.pack(fill="x", padx=12, pady=(10, 4))

        # Status lamp (● indicator)
        lamp = tk.Label(top_row, text="●", bg=BG_CARD, fg=TXT_MUT,
                        font=("Segoe UI", 11))
        lamp.pack(side="left", padx=(0, 6))
        self._feature_lamps[idx] = lamp

        # Feature name
        name_lbl = tk.Label(top_row, text=feat["name"], bg=BG_CARD, fg=TXT_PRI,
                             font=("Segoe UI", 11, "bold"))
        name_lbl.pack(side="left")

        # Script badge
        if not feat.get("builtin") and feat.get("script"):
            tk.Label(top_row, text=f"  📄 {feat['script']}",
                     bg=BG_CARD, fg=TXT_MUT,
                     font=("Segoe UI", 8)).pack(side="left", padx=6)
        elif feat.get("builtin"):
            tk.Label(top_row, text="  ⚡ built-in",
                     bg=BG_CARD, fg=TXT_MUT,
                     font=("Segoe UI", 8)).pack(side="left", padx=6)

        # Description
        if feat.get("description"):
            tk.Label(card, text=feat["description"], bg=BG_CARD, fg=TXT_SEC,
                     font=("Segoe UI", 8), justify="left",
                     wraplength=340).pack(anchor="w", padx=12, pady=(0, 8))

        # Toggle button
        btn_colour = LOCK_RED if is_lockdown else ACCENT
        btn = tk.Button(card,
                        text=f"Enable  {feat['name']}",
                        bg=btn_colour, fg="#ffffff",
                        activebackground=ACCENT_LT, activeforeground="#ffffff",
                        font=("Segoe UI", 9, "bold"), relief="flat",
                        cursor="hand2", padx=14, pady=6,
                        command=lambda i=idx: self._toggle_feature(i))
        btn.pack(anchor="w", padx=12, pady=(0, 10))
        self._feature_btns[idx] = btn

        # Runtime status (PID / running state) — only for external scripts
        if not feat.get("builtin") and feat.get("script"):
            status_lbl = tk.Label(card, text="○ Not running",
                                  bg=BG_CARD, fg=TXT_MUT,
                                  font=("Segoe UI", 8))
            status_lbl.pack(anchor="w", padx=12, pady=(0, 4))
            self._feature_status_lbls[idx] = status_lbl

        # Debug toggle — pipes the plugin's stdout/stderr into the log,
        # tagging anything that looks like an error or warning
        if not feat.get("builtin") and feat.get("script"):
            dbg_on = self._debug_states.get(idx, False)
            dbg = tk.Button(card,
                            text="🐞  Debug: ON" if dbg_on else "🐞  Debug: OFF",
                            bg="#2a2010" if dbg_on else BG_DARK,
                            fg=WARNING if dbg_on else TXT_SEC,
                            activebackground=BORDER, activeforeground=TXT_PRI,
                            font=("Segoe UI", 8), relief="flat",
                            cursor="hand2", padx=10, pady=4,
                            command=lambda i=idx: self._toggle_debug(i))
            dbg.pack(anchor="w", padx=12, pady=(0, 4))
            self._debug_btns[idx] = dbg

        # Reset button — only for external (non-builtin) script plugins
        if not feat.get("builtin") and feat.get("script"):
            rst = tk.Button(card,
                            text="↺  Reset Plugin",
                            bg=BG_DARK, fg=TXT_SEC,
                            activebackground=BORDER, activeforeground=TXT_PRI,
                            font=("Segoe UI", 8), relief="flat",
                            cursor="hand2", padx=10, pady=4,
                            command=lambda i=idx: self._reset_feature(i))
            rst.pack(anchor="w", padx=12, pady=(0, 10))

    def _reset_feature(self, idx: int):
        """Kill and hard-restart a plugin script, regardless of toggle state."""
        feat = FEATURES[idx]
        script = feat.get("script")
        if not script:
            return
        if not self.bot_wrapper:
            messagebox.showwarning(APP_NAME, "Bot is not connected yet.")
            return

        self._append_log(f"↺ Resetting plugin: {feat['name']}  ({script})", "WARNING")

        # Kill any running instance
        _kill_plugin_proc(script)

        # Only re-launch if the plugin was toggled ON
        if self._feature_states.get(idx, False):
            ok, msg = launch_feature_script(
                script, self.bot_wrapper.token, "on",
                debug=self._debug_states.get(idx, False),
                log_cb=self._append_log)
            if ok:
                self._append_log(f"  ✓ Plugin restarted: {feat['name']}", "SUCCESS")
            else:
                self._append_log(f"  ✗ Restart failed: {msg}", "ERROR")
                messagebox.showerror(APP_NAME, f"Could not restart plugin:\n{msg}")
        else:
            self._append_log(
                f"  Plugin was OFF — process killed. Toggle it on to start fresh.",
                "INFO"
            )
        self._update_feature_status(idx)

    def _toggle_feature(self, idx: int):
        feat       = FEATURES[idx]
        currently  = self._feature_states[idx]
        turning_on = not currently

        # ── Lockdown: special double-confirm dialog ───────────────────────────
        if feat.get("builtin_key") == "lockdown" and turning_on:
            dlg = LockdownDialog(self)
            if not dlg.result:
                return   # User cancelled

        # ── External script feature ───────────────────────────────────────────
        if not feat.get("builtin") and feat.get("script"):
            if not self.bot_wrapper:
                messagebox.showwarning(APP_NAME, "Bot is not connected yet.")
                return
            if turning_on:
                ok, msg = launch_feature_script(
                    feat["script"], self.bot_wrapper.token, "on",
                    debug=self._debug_states.get(idx, False),
                    log_cb=self._append_log)
                if not ok:
                    messagebox.showerror(APP_NAME,
                                         f"Could not launch script:\n{msg}")
                    return
                self._append_log(
                    f"▶ Started plugin: {feat['name']}  ({feat['script']})",
                    "SUCCESS")
            else:
                # Hard-kill the process rather than hoping the script notices
                _kill_plugin_proc(feat["script"])
                self._append_log(
                    f"■ Stopped plugin: {feat['name']}  ({feat['script']})",
                    "INFO")

        # ── Built-in: lockdown ────────────────────────────────────────────────
        if feat.get("builtin_key") == "lockdown":
            if self.bot_wrapper:
                self.bot_wrapper.set_lockdown(turning_on)
            else:
                messagebox.showwarning(APP_NAME, "Bot is not connected yet.")
                return

        # ── Update UI state ───────────────────────────────────────────────────
        self._feature_states[idx] = turning_on
        self._refresh_feature_card(idx)
        self._update_feature_status(idx)

    def _refresh_feature_card(self, idx: int):
        feat    = FEATURES[idx]
        active  = self._feature_states[idx]
        btn     = self._feature_btns[idx]
        lamp    = self._feature_lamps[idx]
        is_lock = feat.get("builtin_key") == "lockdown"

        if active:
            lamp.config(fg=LOCK_RED if is_lock else SUCCESS)
            btn.config(
                text=f"Disable  {feat['name']}",
                bg="#1a1a1a" if is_lock else "#1a2a1a",
                fg=LOCK_RED if is_lock else SUCCESS,
                activebackground=BG_CARD,
            )
        else:
            lamp.config(fg=TXT_MUT)
            btn.config(
                text=f"Enable  {feat['name']}",
                bg=LOCK_RED if is_lock else ACCENT,
                fg="#ffffff",
                activebackground=ACCENT_LT,
            )

    def _toggle_debug(self, idx: int):
        """
        Flips debug-capture on/off for a plugin. If the plugin is currently
        running, it's transparently restarted so the new stdout/stderr
        capture setting takes effect immediately.
        """
        feat    = FEATURES[idx]
        enabled = not self._debug_states.get(idx, False)
        self._debug_states[idx] = enabled
        self._refresh_debug_btn(idx)
        self._append_log(
            f"🐞  Debug logging {'enabled' if enabled else 'disabled'} "
            f"for {feat['name']}", "INFO")

        if self._feature_states.get(idx, False) and self.bot_wrapper:
            script = feat.get("script")
            ok, msg = launch_feature_script(
                script, self.bot_wrapper.token, "on",
                debug=enabled, log_cb=self._append_log)
            if ok:
                self._append_log(
                    f"  ↺ Restarted {feat['name']} "
                    f"(debug {'on' if enabled else 'off'})", "SUCCESS")
            else:
                self._append_log(f"  ✗ Restart failed: {msg}", "ERROR")
            self._update_feature_status(idx)

    def _refresh_debug_btn(self, idx: int):
        btn = self._debug_btns.get(idx)
        if btn is None:
            return
        enabled = self._debug_states.get(idx, False)
        btn.config(
            text="🐞  Debug: ON" if enabled else "🐞  Debug: OFF",
            bg="#2a2010" if enabled else BG_DARK,
            fg=WARNING if enabled else TXT_SEC,
        )

    def _update_feature_status(self, idx: int):
        """Refresh the 'Running — PID ####' line under a plugin card."""
        feat = FEATURES[idx]
        lbl  = self._feature_status_lbls.get(idx)
        if lbl is None:
            return
        script = feat.get("script")
        proc   = _plugin_procs.get(script)
        if proc is not None and proc.poll() is None:
            lbl.config(text=f"●  Running — PID {proc.pid}", fg=SUCCESS)
        elif self._feature_states.get(idx, False):
            lbl.config(text="⚠  Marked ON but no process found", fg=WARNING)
        else:
            lbl.config(text="○  Not running", fg=TXT_MUT)

    def _poll_plugin_health(self):
        """Periodically checks tracked plugin processes and catches silent crashes."""
        for idx, feat in enumerate(FEATURES):
            if feat.get("builtin") or not feat.get("script"):
                continue
            script = feat["script"]
            proc   = _plugin_procs.get(script)
            was_on = self._feature_states.get(idx, False)
            if was_on and (proc is None or proc.poll() is not None):
                _plugin_procs.pop(script, None)
                self._feature_states[idx] = False
                self._append_log(
                    f"✗ Plugin exited unexpectedly: {feat['name']}", "ERROR")
                self._refresh_feature_card(idx)
            self._update_feature_status(idx)
        self.after(4000, self._poll_plugin_health)

    def _show_servers_dialog(self):
        """Opens a dialog listing every server the bot is currently in."""
        if not self.bot_wrapper or not self.bot_wrapper.bot:
            messagebox.showwarning(APP_NAME, "Bot is not connected yet.")
            return
        ServersDialog(self, self.bot_wrapper.get_guilds())

    def _show_channel_browser(self):
        """Opens the Channels browser (categories → text/voice channels)."""
        if not self.bot_wrapper or not self.bot_wrapper.bot:
            messagebox.showwarning(APP_NAME, "Bot is not connected yet.")
            return
        ChannelBrowserDialog(self, self.bot_wrapper, self._append_log)

    # ── Right panel (log) ─────────────────────────────────────────────────────
    def _build_right(self, parent):
        p = tk.Frame(parent, bg=BG_PANEL,
                     highlightthickness=1, highlightbackground=BORDER)

        hdr = tk.Frame(p, bg=BG_PANEL)
        hdr.pack(fill="x", padx=14, pady=(14, 6))
        tk.Label(hdr, text="Live Activity Log", bg=BG_PANEL, fg=ACCENT_LT,
                 font=("Segoe UI", 10, "bold")).pack(side="left")
        clr = tk.Label(hdr, text="Clear", bg=BG_PANEL, fg=TXT_MUT,
                       font=("Segoe UI", 8), cursor="hand2")
        clr.pack(side="right")
        clr.bind("<Button-1>", lambda _: self._clear_log())

        tk.Frame(p, bg=BORDER, height=1).pack(fill="x", padx=14)

        log_f = tk.Frame(p, bg=LOG_BG)
        log_f.pack(fill="both", expand=True, padx=8, pady=8)

        self._log = tk.Text(
            log_f, bg=LOG_BG, fg=TXT_PRI,
            font=("Cascadia Mono", 8),
            relief="flat", bd=0, state="disabled",
            wrap="word", cursor="arrow",
            selectbackground=ACCENT, selectforeground="#fff",
        )
        sb = ttk.Scrollbar(log_f, orient="vertical", command=self._log.yview)
        self._log.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self._log.pack(fill="both", expand=True, padx=(6, 0), pady=4)

        self._log.tag_configure("TIME",    foreground=TXT_MUT)
        self._log.tag_configure("INFO",    foreground=TXT_SEC)
        self._log.tag_configure("SUCCESS", foreground=SUCCESS)
        self._log.tag_configure("WARNING", foreground=WARNING)
        self._log.tag_configure("ERROR",   foreground=ERR)
        self._log.tag_configure("MSG",     foreground=TXT_PRI)

        return p

    # ═══ Runtime helpers ═══════════════════════════════════════════════════════
    def _append_log(self, msg: str, level: str = "INFO"):
        self.after(0, self._write_log, msg, level)

    def _write_log(self, msg: str, level: str):
        t = time.strftime("%H:%M:%S")
        self._log.config(state="normal")
        self._log.insert("end", f"[{t}] ", "TIME")
        self._log.insert("end", f"{msg}\n", level)
        lines = int(self._log.index("end-1c").split(".")[0])
        if lines > LOG_MAX:
            self._log.delete("1.0", f"{lines - LOG_MAX}.0")
        self._log.config(state="disabled")
        self._log.see("end")

    def _clear_log(self):
        self._log.config(state="normal")
        self._log.delete("1.0", "end")
        self._log.config(state="disabled")

    def _poll_bot_info(self):
        if not self.bot_wrapper:
            return
        info = self.bot_wrapper.info
        if info:
            self._dot.config(fg=SUCCESS)
            self._status_lbl.config(text="Connected", fg=SUCCESS)
            parts = str(info.get("name", "Bot")).split("#")
            self._bname.config(text=parts[0])
            self._btag.config(text=f"#{parts[1]}" if len(parts) > 1 else "")
            self._info["User ID"].config(text=str(info.get("id", "—")))
            self._info["Servers"].config(text=str(info.get("guild_count", "—")))
            ping  = info.get("ping", "—")
            pclr  = SUCCESS if isinstance(ping, int) and ping < 100 else \
                    WARNING if isinstance(ping, int) and ping < 250 else ERR
            self._info["Ping"].config(
                text=f"{ping} ms" if isinstance(ping, int) else "—", fg=pclr)
            if not self._bot_avatar_photo and info.get("avatar_url"):
                self.after(0, self._load_avatar, info["avatar_url"])

            connected_at = self.bot_wrapper.connected_at
            if connected_at:
                elapsed = int(time.time() - connected_at)
                h, rem  = divmod(elapsed, 3600)
                m, s    = divmod(rem, 60)
                self._uptime_lbl.config(text=f"⏱  {h:02}:{m:02}:{s:02}")
        else:
            self._dot.config(fg=WARNING)
            self._status_lbl.config(text="Connecting…", fg=WARNING)
            self._uptime_lbl.config(text="")
        self.after(5000, self._poll_bot_info)

    def _load_avatar(self, url: str):
        try:
            data = requests.get(url, timeout=6).content
            img  = Image.open(BytesIO(data)).convert("RGBA").resize((88, 88))
            mask = Image.new("L", (88, 88), 0)
            ImageDraw.Draw(mask).ellipse((0, 0, 87, 87), fill=255)
            img.putalpha(mask)
            self._bot_avatar_photo = ImageTk.PhotoImage(img)
            self._av_lbl.config(image=self._bot_avatar_photo)
        except Exception:
            pass

    # ═══ Disconnect / close ════════════════════════════════════════════════════
    def _disconnect(self):
        if messagebox.askyesno(APP_NAME,
                               "Disconnect the bot and return to the token screen?"):
            self._teardown()
            for w in self.winfo_children():
                w.destroy()
            self._feature_btns.clear()
            self._feature_lamps.clear()
            self._feature_status_lbls.clear()
            self._debug_btns.clear()
            self._feature_states = {i: False for i in range(len(FEATURES))}
            self._build_token_screen()

    def _teardown(self):
        # 1. Kill all external plugin processes first so nothing lingers
        kill_all_plugins()
        # 2. Shut down the Discord bot (waits for clean close)
        if self.bot_wrapper:
            self.bot_wrapper.stop()
            self.bot_wrapper = None
        self._bot_avatar_photo = None

    def _on_close(self):
        self._teardown()
        self.destroy()


# ─── Entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = HexysApp()
    app.mainloop()