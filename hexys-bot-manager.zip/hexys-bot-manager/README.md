# Hexy's Bot Manager

A desktop dashboard (Tkinter) for running and managing a Discord bot — toggle
features on/off, watch live logs, browse your server's channels and voice
chats in real time, and moderate members, all from one window.

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![License: MIT](https://img.shields.io/badge/license-MIT-green)

## Features

- **Plugin system** — toggle bot features on/off from the UI. Ships with:
  - `/math` — expression evaluator, unit conversions, constants
  - `/weather` — live weather lookup for any city, with autocomplete
  - An example plugin template so you can write your own
- **Live dashboard** — connection status, ping, uptime, per-plugin PID/status
- **Debug mode** — pipe any plugin's stdout/stderr straight into the log,
  with automatic error/warning highlighting
- **Servers view** — see every server the bot is in, with icons and member counts
- **Chat browser** — expand every category and channel in a server; open a
  text channel to watch its live chat, or a voice channel to see who's
  connected (both update in real time, no refresh needed)
- **Moderation** — click any username to Kick, Timeout, or Ban them directly,
  with a duration picker for timeouts and temporary bans
- **Persistent temp-bans** — a temporary ban's exact expiry (full date +
  time, not just a clock time) is saved to disk, so if the app is closed and
  reopened later, it still un-bans at the right moment instead of getting
  confused by day changes
- **Send messages** — post a staff message to any channel straight from the
  chat viewer
- **Lockdown mode** — a panic button that blocks all bot commands and
  auto-deletes anything the bot tries to send

## Requirements

- Python 3.10+
- A Discord bot application ([Discord Developer Portal](https://discord.com/developers/applications))

## Setup

1. **Clone or download this repo.**

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Create a Discord bot** at the [Developer Portal](https://discord.com/developers/applications):
   - New Application → Bot → Reset Token, copy it somewhere safe
   - Under **Privileged Gateway Intents**, enable:
     - **Server Members Intent**
     - **Message Content Intent**
   - Under **OAuth2 → URL Generator**, check `bot` and `applications.commands`,
     then give it at minimum: `Kick Members`, `Ban Members`, `Moderate Members`,
     `Send Messages`, `Read Message History`, `View Channels`, `Connect`
   - Use the generated URL to invite the bot to your server

4. **Run the app:**
   ```bash
   python hexys_bot_manager.py
   ```
   Paste your bot token into the connect screen. That's it — the app creates
   its own `hexy_config.json`, `logs/`, `plugins/`, and `assets/` folders on
   first launch (all git-ignored, so your token never gets committed).

## Adding your own plugin

Every plugin is a standalone Python script launched as:

```
python your_plugin.py --token BOT_TOKEN --state on|off
```

1. Copy `example_plugin.py` as a starting point.
2. Write your feature logic in `run_feature()`.
3. Register it in `hexys_bot_manager.py` by adding an entry to the
   `FEATURES` list near the top of the file:

   ```python
   {
       "name":        "My Feature",
       "description": "What it does.",
       "script":      "my_plugin.py",
       "builtin":     False,
   },
   ```
4. Restart the manager — a new toggle card appears automatically.

## A note on temporary bans

Discord itself doesn't support temporary bans natively (unlike timeouts,
which Discord's own servers expire automatically even if this app isn't
running). A temp-ban set through this manager only auto-expires while the
manager process is running — if you close it before the ban is due to lift,
the ban stays in place until you reopen the app (at which point it picks the
countdown back up from the real stored expiry time) or unban the person
manually.

## License

MIT — see [LICENSE](LICENSE). Feel free to swap this out if you'd rather use
a different license for your fork.
